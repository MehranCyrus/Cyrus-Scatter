Cyrus collision and solver reuse — research evidence

Open the accompanying HTML for interpretation and evidence labels.
Run on the recorded Linux single-config setup: python3 collision_study/reproduce.py
Run analytic fixture checks: python3 collision_study/fixture_oracles.py

The native wrapper downloads the exact public Jolt commit and checks hashes.
No static fitter, custom rod contacts, GPU hair, Max or renderer is implemented by this bundle.
Fixtures intentionally expose invalid geometry; zero engine errors do not mean geometric success.
No benchmark measurements are reported.

Original probe/oracle code supplied for inspection and reproduction. Jolt excerpts retain upstream license notices.

"""Analytic fixture oracles; not a contact solver or a Jolt benchmark.

Run: python3 collision_study/fixture_oracles.py
The native Jolt harness is separate and has its own recorded results.
"""
from pathlib import Path
import json, math, struct

ROOT = Path(__file__).resolve().parent

def dot(a, b): return sum(x*y for x, y in zip(a, b))
def sub(a, b): return tuple(x-y for x, y in zip(a, b))
def norm(a): return math.sqrt(dot(a, a))
def f32(x): return struct.unpack('f', struct.pack('f', x))[0]
def segment_distance(point, a, b):
    ab, ap = sub(b, a), sub(point, a)
    t = max(0., min(1., dot(ap, ab)/dot(ab, ab)))
    return norm(sub(point, tuple(a[i] + t*ab[i] for i in range(3))))

fixtures = []
def record(id, title, inputs, checks, interpretation):
    assert all(checks.values()), (id, checks)
    fixtures.append(dict(id=id, title=title, evidence='Executed analytic oracle; no physics integration',
                         inputs=inputs, checks=checks, interpretation=interpretation))

a, b, o = (-2.,0.,0.), (2.,0.,0.), (0.,0.,0.)
record('F01','Endpoints clear; segment crosses',dict(a=a,b=b,sphere_radius=1.,guide_radius=.01),
       dict(endpoints_outside=min(norm(a),norm(b))>1.01,
            segment_overlaps=segment_distance(o,a,b)<1.01),
       'A particle-only witness set misses the interior of this span. Native H01/H02 test the same boundary.')

corners=[(x,y,0.) for x in (-.25,.25) for y in (-.1,.1)]
record('F02','Blade completely inside a solid',dict(corners=corners,sphere_radius=1.,maximum_corner_radius=max(map(norm,corners))),
       dict(entire_rectangle_inside=max(map(norm,corners))<1.),
       'Convexity of the ball proves the whole rectangular patch is inside. Surface intersection alone is insufficient.')

record('F03','Root inside obstacle',dict(root=(.2,0.,0.),sphere_radius=1.,clearance=.01),
       dict(hard_anchor_infeasible=.2<1.01),
       'A hard position equality conflicts with positive obstacle clearance. No iteration count can satisfy both.')

record('F04','Narrow gap and width',dict(gap=.12,projected_blade_width=.20,guide_diameter=.02,clearance_each_side=.01),
       dict(guide_fits=.02+2*.01<.12,fixed_width_does_not=.20+2*.01>.12),
       'This impossibility assumes the declared cross-section orientation. Allowing twist may permit an edge-on solution.')

record('F05','Sharp corner requires multiple contacts',dict(start=(-.1,-.1),after_x_projection=(0.,-.1),feasible_halfspaces=['x>=0','y>=0']),
       dict(one_plane_leaves_violation=-.1<0,multi_plane_solution_exists=0>=0),
       'One face projection leaves another active inequality violated. This is a simplified corner algebra check, not a Jolt corner simulation.')

record('F06','Open mesh has no declared solid interior',dict(square_boundary_edges=4,manifold_closed=False),
       dict(volume_contract_fails=4>0),
       'A single square is an open surface. Inside/outside must be replaced by an explicit surface, half-space or closed-proxy policy.')

record('F07','Millimetre features and metre defaults',dict(asset_height_m=.005,thickness_m=.0001,
       rigid_penetration_slop_m=.02,gjk_collision_tolerance_m=.0001,
       slop_over_height=.02/.005,tolerance_over_thickness=.0001/.0001),
       dict(slop_larger_than_asset=.02>.005,tolerance_equals_thickness=.0001==.0001),
       'Dimensionless ratios only. Rigid settings are not automatically CPU-soft-body settings; this is not a millimetre Jolt simulation.')

origin=1e8; target=origin+.01
record('F08','Large coordinates erase small offsets before rebasing',dict(origin=origin,offset=.01,
       cast_before_rebase=f32(target)-f32(origin),rebase_before_cast=f32(target-origin)),
       dict(cast_before_rebase_loses_offset=f32(target)-f32(origin)==0.,
            rebase_first_retains_offset=abs(f32(target-origin)-.01)<1e-7),
       'IEEE float arithmetic only, not a Jolt double-precision build test. Rebase while host values still retain the needed precision.')

# Guide runs parallel to y at x=1.1, while a 0.3-wide ribbon reaches x=.95.
guide_a=(1.1,-.4,0.); guide_b=(1.1,.4,0.); edge=(.95,0.,0.)
record('F09','Visible edge reaches beyond a clear guide',dict(guide_a=guide_a,guide_b=guide_b,
       sphere_radius=1.,guide_radius=.01,blade_width=.3,inner_edge_midpoint=edge),
       dict(guide_clear=segment_distance(o,guide_a,guide_b)>1.01,edge_inside=norm(edge)<1.),
       'A clear narrow guide cannot certify the evaluated blade. Width, twist and between-sample surface regions need a declared envelope or final-surface test.')

out=dict(kind='Analytic fixture checks; not solver execution',units='metres except stated dimensionless values',
         fixture_count=len(fixtures),boolean_check_count=sum(len(x['checks']) for x in fixtures),
         all_checks_passed=True,fixtures=fixtures)
(ROOT/'analytic_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='fixtures'}))

# Exact Jolt pin provenance and executed CPU probes

## Evidence boundary

This task downloaded and directly inspected public Jrouwe/JoltPhysics source at **`1b2e77e3c6c09709e5edc79dc208459b8ff32051`**, then built that source and executed the small C++ harness in `harness/probe.cpp`. These are native **executed tests**, distinct from source inspection and proposed Cyrus designs. No Cyrus binary, Max 2027 plug-in, renderer, GPU hair pipeline, artist asset, or production scene was run. The user supplied the pin, reported header version, and existing rigid-path context. The local Cyrus dependency declaration file and its compile switches were not available for audit; the switches recorded below belong only to this research harness. This run validates a public source snapshot, not the full private integration.

## Provenance

The GitHub commit API resolves the exact hash to a commit dated **2026-10-14 19:54:27 UTC**, titled “Changed Mutex::mLockedThreadID to an atomic (#2162)”. The downloaded codeload archive contains 19,399,443 bytes and has SHA-256 **`6bb6d626b7b70096cd07f1b25c0c223df035ab6386885f07f77baa88ae7d3998`**. Source is under `vendor/jolt_pin`; API evidence is saved under `vendor/`. [P01, P03, P11]

At this pin `Jolt/Core/Core.h:8–10` defines **5.6.1**, while `Build/CMakeLists.txt:3` still declares **5.6.0**. Identify this dependency by its full SHA plus header version. Do not describe it as the tagged v5.6.0 source or assert that it is a tagged v5.6.1 release. [P01, P02]

The **v5.6.0** tag resolves to `e77f175595e64cb44218cc9d9d56fc365ad0e36a`. GitHub's comparison places the supplied pin **62 commits ahead**, with **78 changed files**. The checked tag versions of `SoftBodySharedSettings.h`, `SoftBodyCosseratRodConstraintTest.cpp`, and `Hair.h` are byte-identical to the pinned versions. The inspected `SoftBodyMotionProperties.cpp` diff replaces division/square-root expressions with `MulRSqrtApproximate` in the dihedral and long-range-attachment paths; the rod implementation is unchanged in that diff. No `Hair`/`hair` path appears in the comparison's changed-files list. This does not imply all tag-to-pin behavior is identical: collision, rigid contacts, and other helpers changed. [P04, P05]

The pin's release notes distinguish **CPU SoftBody Cosserat rods (added in v5.4.0)** from **GPU strand hair (added in v5.6.0, explicitly work in progress)**. The latter has guide/follow hairs, scalp skinning, compute backends, and restricted environment shape support. These are separate code paths in the same repository. The CPU tests here disabled every compute backend; they exercise neither GPU hair nor its CPU-compute fallback. [P06]

## Build and reproduction

The source tree was not patched. A separate CMake project adds its `Build` directory as a subproject and links the `Jolt` target. Exact harness configuration is in `harness/CMakeLists.txt`. It was built on Linux x86-64 with **GCC 13.3.0 (Ubuntu 13.3.0-6ubuntu2~24.04)** and **CMake 4.1.0**, Release, assertions on, single-precision world coordinates, SSE2 baseline, IPO/LTO off, debug renderer/profiler off, and all DX12/Vulkan/Metal/CPU-compute backends off. The harness uses `JobSystemSingleThreaded`. These choices are a reproducible research configuration; they are not claims about Cyrus's current compilation settings.

Executed commands from the workspace root:

```sh
python -m pip install --no-deps --target collision_study/build_tools cmake==4.1.0
collision_study/build_tools/cmake/data/bin/cmake -S collision_study/harness -B collision_study/build -DCMAKE_BUILD_TYPE=Release > collision_study/configure.log 2>&1
collision_study/build_tools/cmake/data/bin/cmake --build collision_study/build --target cyrus_jolt_probe -j 4 > collision_study/build_harness.log 2>&1
collision_study/build/cyrus_jolt_probe > collision_study/harness_results.json 2> collision_study/harness_stderr.log
```

`reproduce.py` downloads the exact archive, checks its SHA-256, safely extracts it when absent, locates CMake, configures/builds the unchanged harness and writes the results. It was provided as a repeatable wrapper; the commands above are the actual executed sequence. Install CMake >=3.20, or use the local CMake wheel as above. `pin_provenance.json` records hashes of relevant source, harness, and results files. Build and run both returned exit code 0; final stderr is empty. **No benchmark timing or scaling claim is made.**

## Executed fixture definitions

All geometric quantities below use the harness's meter-scale coordinates. The obstacle is fixed, centered at the origin. Gravity and initial velocity are zero. The soft-body test has three vertices, two consecutive `RodStretchShear` constraints and one `RodBendTwist` constraint between them; this avoids testing a lone unpaired rod. Constraints are initialized through `CalculateRodProperties()` then `Optimize()`. Vertex radius is 0.01. Sleeping and soft-body body-position recentering are disabled. Each dynamic run executes **60 updates of 1/60 second**, collisionSteps=1; default other creation settings are retained. Root-pinned cases set vertex 0 inverse mass to zero; the default initializer also calculates first-rod inverse mass zero. Thus those particular fixtures clamp the first segment's frame as well as root position; they do not test a freely rotating positional root. Source inspection explains how to separate those decisions. [P10]

Contact observations are counted inside `SoftBodyContactListener::OnSoftBodyContactAdded`, using `SoftBodyManifold::HasContact`. Post-update `SoftBodyVertex::mHasContact` is unsuitable because the update resets it after the callback. The raw JSON records listener counts, first-step/final positions, final speed, update error bits, and configured iteration counts; the initial positions appear explicitly in the harness and table below. [P08]

### Native results

| ID | Setup and observation | What this decides |
|---|---|---|
| H01 | Sphere radius 1; points at x=-2 and +2 produce 0 `CollidePoint` hits each. A capsule joining those points (radius .01) produces 1 shape overlap. | Whole-segment contact sees a collision that endpoint tests miss. This is an executed query, not an implemented rod-contact response. |
| H02 / H02b | Rod vertices (-2,0,0),(2,0,0),(3,0,0), first pinned, sphere radius1. After 60 steps, maximum vertex displacement is **6.74349565e-7** for both 5 and 50 constraint iterations; final speed0; no contact callback or contacting vertex. The first segment remains through the stone. | Additional solver iterations do not add absent segment contacts. These tiny changes are floating-point constraint residuals, not meaningful obstacle avoidance. |
| H03 | Capsule half-height .2 and radius .01 wholly inside a solid box with half extents1 and explicit convex radius0 gives 1 overlap. The same capsule inside an outward-wound closed cube `MeshShape` gives 0 overlap with either triangle backface mode. | Ordinary shape-vs-mesh contact is not a solid-containment detector. Turning on backfaces does not manufacture a remote surface contact. |
| H03 containment diagnostic | `CollidePoint` inside the box returns1. For the closed cube mesh it returns1 at interior (.125,.15,.25), but **0 at exact origin**. The origin's +Y ray returns two triangle hits at the same fraction .454545438; the off-axis point returns one hit at .386363626. | Closed-mesh point containment exists, but this pin's raw hit-count parity implementation has a specific shared-edge degeneracy in this fixture. Use robust mesh preprocessing/classification and report ambiguity; do not treat this one-ray result as infallible. |
| H04 | Three free rod vertices (.1,0,0),(.2,0,0),(.3,0,0) lie deep inside the cube mesh. No contact observations; maximum displacement **2.53318557e-8**. | A closed mesh does not automatically push out deeply contained soft-body vertices. |
| H04b | Same free rod inside analytic sphere radius1. First update produces3 contacting vertices and positions x≈1.0450,1.1641,1.2648. After60 steps positions x≈12.7013,12.8013,12.9013 and final max speed≈11.2730. | The solid primitive resolves initial interior contact dynamically. The subsequent motion is an outgoing transient, not a static fitted solution; this test does not establish settling quality. |
| H05 | Rod vertices (.2,0,0),(1.5,0,0),(2.5,0,0), first pinned, sphere radius1. Root remains x≈.200000003, inside the stone. No contact observations; other changes below3e-7. | Pinning an infeasible root does not create an automatic repair policy. The application must reject, relocate with authorization, or explicitly exempt the root. |

All dynamic fixture update error bits are **0**. A zero engine update error therefore does **not** certify geometric correctness or constraint feasibility. A practical diagnostic threshold of 1e-5 in these specific meter-scale fixtures easily distinguishes observed round-off from successful routing, but it is a proposed classification tolerance, not a general production tolerance or Jolt guarantee.

### Why the point-containment exception is reproducible

The cube is the closed, outward-wound triangulation in `cube_mesh()`, with vertices at each sign combination of ±1 and twelve triangles. At its center, the parity ray intersects the diagonal shared by two top-face triangles. `Shape::sCollidePointUsingRayCast` casts along +Y and increments the counter once per hit; it does not deduplicate coincident fractions. Two hits yield even parity. `MeshShape::CollidePoint` delegates directly to that helper. This explains the observed center result without claiming that all manifold mesh queries fail. The example remains useful as an adversarial regression fixture. [P07, P09]

## Smallest remaining experiments

1. Keep H01/H02 as the decisive baseline. Implement one segment-capsule contact constraint and demonstrate that the previously crossing segment is separated while preserving root and length. A capsule query alone is insufficient: response must distribute the correction to endpoints and couple it back to length/bend constraints.
2. Keep H03/H04 as initialization gates. Demonstrate a robust closed-solid inside test plus a specified escape/abort rule. This is needed by a static fitter and by Jolt rods; mesh contact flags alone cannot provide it.
3. Compare default first-rod inverse mass0 against an explicitly movable first-rod frame with root vertex pinned, then add a tunable root orientation constraint. Source inspection supports the distinction; this harness has not executed that comparison.
4. Run the same acceptance fixtures against a focused static fitter and against the proposed rod contact extension. Include edge/width envelopes and final full-segment validation. Choose using implementation surface and regression burden, not these tiny tests' runtime.

Do not extrapolate these tests to narrow-gap routing, all sharp corners, open meshes, extremely small geometry, huge world coordinates, frictional rest states, or production batching: those remain proposed acceptance fixtures unless covered by another explicitly marked executed test.

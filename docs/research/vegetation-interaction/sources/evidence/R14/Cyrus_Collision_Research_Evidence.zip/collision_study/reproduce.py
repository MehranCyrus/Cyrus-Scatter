"""Reproduce the exact-pin CPU probe. Run from any working directory.

Requires Python 3.12+, CMake >=3.20, a supported C++ compiler and build tool.
Uses an installed cmake or the local build_tools/cmake wheel tree. Downloads
only the public exact-commit archive, and verifies it before extraction.
"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import urllib.request

ROOT = Path(__file__).resolve().parent
PIN = "1b2e77e3c6c09709e5edc79dc208459b8ff32051"
SHA256 = "6bb6d626b7b70096cd07f1b25c0c223df035ab6386885f07f77baa88ae7d3998"
vendor = ROOT / "vendor"
source = vendor / "jolt_pin"
archive = vendor / "jolt_pin.tar.gz"
vendor.mkdir(exist_ok=True)
if not source.exists():
    if not archive.exists():
        urllib.request.urlretrieve(
            f"https://codeload.github.com/jrouwe/JoltPhysics/tar.gz/{PIN}", archive)
    actual = hashlib.sha256(archive.read_bytes()).hexdigest()
    if actual != SHA256:
        raise SystemExit(f"Archive SHA-256 mismatch: {actual}")
    with tarfile.open(archive, "r:gz") as tf:
        tf.extractall(vendor, filter="data")
    (vendor / f"JoltPhysics-{PIN}").rename(source)
# If a source directory was already present, refuse a known mismatch rather
# than silently compiling a different revision. These are selected-file
# checks; the verified archive is the stronger full-source provenance.
manifest = json.loads((ROOT / "pin_provenance.json").read_text())
for name, expected in manifest["source_sha256"].items():
    path = source / name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit(f"Pinned source check failed: {path}. Use a fresh source extraction.")
cmake = shutil.which("cmake")
if not cmake:
    local = ROOT / "build_tools/cmake/data/bin/cmake"
    if local.exists():
        cmake = str(local)
if not cmake:
    raise SystemExit("Install CMake >=3.20, or: python -m pip install --no-deps --target collision_study/build_tools cmake==4.1.0")
commands = [
    [cmake, "-S", str(ROOT / "harness"), "-B", str(ROOT / "build"), "-DCMAKE_BUILD_TYPE=Release"],
    [cmake, "--build", str(ROOT / "build"), "--target", "cyrus_jolt_probe", "-j", "4"],
]
for command, name in zip(commands, ["configure.log", "build_harness.log"]):
    with (ROOT / name).open("w") as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
with (ROOT / "harness_results.json").open("w") as out, (ROOT / "harness_stderr.log").open("w") as err:
    subprocess.run([str(ROOT / "build/cyrus_jolt_probe")], stdout=out, stderr=err, check=True)
print(ROOT / "harness_results.json")

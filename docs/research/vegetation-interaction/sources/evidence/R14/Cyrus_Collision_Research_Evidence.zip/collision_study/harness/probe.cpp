// Research harness for the exact pinned Jolt source. Not a Cyrus/Max plug-in.
#include <Jolt/Jolt.h>
#include <Jolt/RegisterTypes.h>
#include <Jolt/Core/Factory.h>
#include <Jolt/Core/TempAllocator.h>
#include <Jolt/Core/JobSystemSingleThreaded.h>
#include <Jolt/Physics/PhysicsSystem.h>
#include <Jolt/Physics/Body/BodyCreationSettings.h>
#include <Jolt/Physics/Body/BodyLock.h>
#include <Jolt/Physics/SoftBody/SoftBodyCreationSettings.h>
#include <Jolt/Physics/SoftBody/SoftBodyMotionProperties.h>
#include <Jolt/Physics/SoftBody/SoftBodyContactListener.h>
#include <Jolt/Physics/SoftBody/SoftBodyManifold.h>
#include <Jolt/Physics/Collision/Shape/SphereShape.h>
#include <Jolt/Physics/Collision/Shape/BoxShape.h>
#include <Jolt/Physics/Collision/Shape/CapsuleShape.h>
#include <Jolt/Physics/Collision/Shape/MeshShape.h>
#include <Jolt/Physics/Collision/CollisionCollectorImpl.h>
#include <Jolt/Physics/Collision/CollisionDispatch.h>
#include <Jolt/Physics/Collision/CollidePointResult.h>
#include <Jolt/Physics/Collision/CollideShape.h>
#include <Jolt/Physics/Collision/RayCast.h>
#include <Jolt/Physics/Collision/CastResult.h>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cstdlib>
using namespace JPH;

class BP final:public BroadPhaseLayerInterface {
public: uint GetNumBroadPhaseLayers()const override{return 2;}
 BroadPhaseLayer GetBroadPhaseLayer(ObjectLayer l)const override{return BroadPhaseLayer(uint8(l));}
};
class ObjPair final:public ObjectLayerPairFilter {
public:bool ShouldCollide(ObjectLayer a,ObjectLayer b)const override{return a==1||b==1;}
};
class ObjBP final:public ObjectVsBroadPhaseLayerFilter {
public:bool ShouldCollide(ObjectLayer a,BroadPhaseLayer b)const override{return a==1||uint8(b)==1;}
};
class ContactCounter final:public SoftBodyContactListener {
public:
 uint callbacks=0,total_vertex_contacts=0,max_vertices_per_step=0;
 void OnSoftBodyContactAdded(const Body&,const SoftBodyManifold& m)override{
  ++callbacks;uint n=0;for(const auto& v:m.GetVertices())if(m.HasContact(v))++n;
  total_vertex_contacts+=n;max_vertices_per_step=std::max(max_vertices_per_step,n);
 }
};
struct World {
 BP bp;ObjPair pair;ObjBP obp;PhysicsSystem sys;
 TempAllocatorImpl temp{16*1024*1024};JobSystemSingleThreaded jobs{1024};
 World(){sys.Init(128,0,128,128,bp,obp,pair);sys.SetGravity(Vec3::sZero());}
};
static void vec(Vec3Arg p){std::cout<<'['<<p.GetX()<<','<<p.GetY()<<','<<p.GetZ()<<']';}
static size_t point_hits(const Shape* s,Vec3Arg p){
 AllHitCollisionCollector<CollidePointCollector> c;
 s->CollidePoint(p,SubShapeIDCreator(),c);return c.mHits.size();
}
static void point_ray_hits(const Shape* s,Vec3Arg p){
 AllHitCollisionCollector<CastRayCollector> c;RayCastSettings rs;rs.SetBackFaceMode(EBackFaceMode::CollideWithBackFaces);
 s->CastRay(RayCast{p,1.1f*s->GetLocalBounds().GetSize().GetY()*Vec3::sAxisY()},rs,SubShapeIDCreator(),c);
 std::cout<<'[';for(size_t i=0;i<c.mHits.size();++i){if(i)std::cout<<',';std::cout<<c.mHits[i].mFraction;}std::cout<<']';
}
static size_t overlap(const Shape* a,const Shape* b,Mat44Arg ta=Mat44::sIdentity(),EBackFaceMode mode=EBackFaceMode::IgnoreBackFaces){
 CollideShapeSettings s;s.mBackFaceMode=mode;
 AllHitCollisionCollector<CollideShapeCollector> c;
 CollisionDispatch::sCollideShapeVsShape(a,b,Vec3::sOne(),Vec3::sOne(),ta,Mat44::sIdentity(),SubShapeIDCreator(),SubShapeIDCreator(),s,c);
 return c.mHits.size();
}
static Ref<Shape> cube_mesh(){
 // Closed outward-wound unit-half-extent cube; triangle shell, not a volume primitive.
 const Vec3 v[8]={{-1,-1,-1},{1,-1,-1},{1,1,-1},{-1,1,-1},{-1,-1,1},{1,-1,1},{1,1,1},{-1,1,1}};
 const uint32 t[12][3]={{0,2,1},{0,3,2},{4,5,6},{4,6,7},{0,1,5},{0,5,4},{3,7,6},{3,6,2},{0,4,7},{0,7,3},{1,2,6},{1,6,5}};
 TriangleList tris;for(const auto& f:t)tris.push_back(Triangle(v[f[0]],v[f[1]],v[f[2]]));
 MeshShapeSettings s(tris);auto r=s.Create();if(r.HasError()){std::cerr<<r.GetError();std::exit(2);}return r.Get();
}
static void rod_run(const char* id,const Shape* stone,const std::vector<Vec3>& p,bool root_fixed,int iterations=5){
 ContactCounter counter;World w;w.sys.SetSoftBodyContactListener(&counter);
 auto& bi=w.sys.GetBodyInterface();
 BodyCreationSettings obstacle(stone,RVec3::sZero(),Quat::sIdentity(),EMotionType::Static,0);
 BodyID obstacle_id=bi.CreateAndAddBody(obstacle,EActivation::DontActivate);
 Ref<SoftBodySharedSettings> s=new SoftBodySharedSettings;
 for(size_t i=0;i<p.size();++i){SoftBodySharedSettings::Vertex v;p[i].StoreFloat3(&v.mPosition);v.mInvMass=(root_fixed&&i==0)?0.f:1.f;s->mVertices.push_back(v);}
 for(uint32 i=1;i<p.size();++i)s->mRodStretchShearConstraints.push_back(SoftBodySharedSettings::RodStretchShear(i-1,i));
 for(uint32 i=1;i<s->mRodStretchShearConstraints.size();++i)s->mRodBendTwistConstraints.push_back(SoftBodySharedSettings::RodBendTwist(i-1,i));
 s->CalculateRodProperties();float first_rod_inv=s->mRodStretchShearConstraints[0].mInvMass;s->Optimize();
 SoftBodyCreationSettings cs(s,RVec3::sZero(),Quat::sIdentity(),1);
 cs.mGravityFactor=0;cs.mUpdatePosition=false;cs.mAllowSleeping=false;cs.mVertexRadius=.01f;cs.mNumIterations=iterations;
 BodyID idbody=bi.CreateAndAddSoftBody(cs,EActivation::Activate);
 std::vector<Vec3> first_step;uint errors=0;for(int i=0;i<60;++i){errors|=uint(w.sys.Update(1.f/60,1,&w.temp,&w.jobs));if(i==0){BodyLockRead lock(w.sys.GetBodyLockInterface(),idbody);auto* mp=static_cast<const SoftBodyMotionProperties*>(lock.GetBody().GetMotionProperties());for(const auto& v:mp->GetVertices())first_step.push_back(v.mPosition);}}
 {
  BodyLockRead lock(w.sys.GetBodyLockInterface(),idbody);const Body& body=lock.GetBody();
  auto* mp=static_cast<const SoftBodyMotionProperties*>(body.GetMotionProperties());
  std::cout<<"{\"id\":\""<<id<<"\",\"steps\":60,\"dt\":0.0166666667,\"iterations\":"<<iterations<<",\"vertex_radius\":0.01,\"first_rod_inverse_mass\":"<<first_rod_inv<<",\"update_error_bits\":"<<errors<<",\"positions\":[";
  float max_move=0,max_speed=0;
  for(uint i=0;i<mp->GetVertices().size();++i){if(i)std::cout<<',';const auto& v=mp->GetVertex(i);vec(v.mPosition);max_move=std::max(max_move,(v.mPosition-p[i]).Length());max_speed=std::max(max_speed,v.mVelocity.Length());}
  std::cout<<"],\"first_step_positions\":[";for(size_t i=0;i<first_step.size();++i){if(i)std::cout<<',';vec(first_step[i]);}
  std::cout<<"],\"max_vertex_displacement\":"<<max_move<<",\"final_max_vertex_speed\":"<<max_speed<<",\"listener_callbacks\":"<<counter.callbacks<<",\"total_vertex_contact_observations\":"<<counter.total_vertex_contacts<<",\"max_contacting_vertices_in_one_step\":"<<counter.max_vertices_per_step<<"}";
 }
 bi.RemoveBody(idbody);bi.DestroyBody(idbody);bi.RemoveBody(obstacle_id);bi.DestroyBody(obstacle_id);
}
int main() {
 RegisterDefaultAllocator();Factory::sInstance=new Factory();RegisterTypes();
 std::cout<<std::setprecision(9);
 {
  Ref<Shape> sphere=new SphereShape(1.f);Ref<Shape> box=new BoxShape(Vec3::sOne(),0.f);Ref<Shape> mesh=cube_mesh();
  Ref<Shape> long_capsule=new CapsuleShape(2.f,.01f);Ref<Shape> short_capsule=new CapsuleShape(.2f,.01f);
  Mat44 x_axis=Mat44::sRotation(Quat::sRotation(Vec3::sAxisZ(),.5f*JPH_PI));
  std::cout<<"{\"pin\":\"1b2e77e3c6c09709e5edc79dc208459b8ff32051\",\"version\":\""<<JPH_VERSION_MAJOR<<'.'<<JPH_VERSION_MINOR<<'.'<<JPH_VERSION_PATCH<<"\",\"precision\":\"single\",\"compute_backends\":\"all disabled\",\"jobs\":\"single threaded\",\"results\":[\n";
  std::cout<<"{\"id\":\"H01\",\"case\":\"endpoints outside sphere, segment crosses\",\"endpoint_minus_hits\":"<<point_hits(sphere,Vec3(-2,0,0))<<",\"endpoint_plus_hits\":"<<point_hits(sphere,Vec3(2,0,0))<<",\"capsule_overlap_hits\":"<<overlap(long_capsule,sphere,x_axis)<<"},\n";
  rod_run("H02_rod_crosses_sphere",sphere,{{-2,0,0},{2,0,0},{3,0,0}},true);std::cout<<",\n";
  rod_run("H02b_rod_crosses_sphere_more_iterations",sphere,{{-2,0,0},{2,0,0},{3,0,0}},true,50);std::cout<<",\n";
  std::cout<<"{\"id\":\"H03\",\"case\":\"capsule wholly contained\",\"box_overlap_hits\":"<<overlap(short_capsule,box)<<",\"mesh_overlap_ignore_backfaces\":"<<overlap(short_capsule,mesh)<<",\"mesh_overlap_collide_backfaces\":"<<overlap(short_capsule,mesh,Mat44::sIdentity(),EBackFaceMode::CollideWithBackFaces)<<",\"box_center_point_hits\":"<<point_hits(box,Vec3::sZero())<<",\"mesh_center_point_hits\":"<<point_hits(mesh,Vec3::sZero())<<",\"mesh_off_axis_point_hits\":"<<point_hits(mesh,Vec3(.125f,.15f,.25f))<<",\"mesh_center_parity_ray_fractions\":";point_ray_hits(mesh,Vec3::sZero());std::cout<<",\"mesh_off_axis_parity_ray_fractions\":";point_ray_hits(mesh,Vec3(.125f,.15f,.25f));std::cout<<"},\n";
  rod_run("H04_rod_inside_mesh",mesh,{{.1f,0,0},{.2f,0,0},{.3f,0,0}},false);std::cout<<",\n";
  rod_run("H04b_rod_inside_sphere",sphere,{{.1f,0,0},{.2f,0,0},{.3f,0,0}},false);std::cout<<",\n";
  rod_run("H05_root_inside_sphere",sphere,{{.2f,0,0},{1.5f,0,0},{2.5f,0,0}},true);std::cout<<"\n]}\n";
 }
 UnregisterTypes();delete Factory::sInstance;Factory::sInstance=nullptr;
}

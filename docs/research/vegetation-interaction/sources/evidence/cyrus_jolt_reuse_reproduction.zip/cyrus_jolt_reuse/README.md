# CyrusScatter / Jolt collision and solver reuse — reproducible diagnostic

This package contains an authored C++ diagnostic and recorded results. It is
not a Cyrus plug-in, full static fitter, production renderer test, GPU hair
example, or benchmark. No wall-clock performance was measured.

## Exact dependency

Repository: https://github.com/jrouwe/JoltPhysics

Commit: 1b2e77e3c6c09709e5edc79dc208459b8ff32051

Archive:
https://codeload.github.com/jrouwe/JoltPhysics/tar.gz/1b2e77e3c6c09709e5edc79dc208459b8ff32051

Downloaded archive SHA256:
6bb6d626b7b70096cd07f1b25c0c223df035ab6386885f07f77baa88ae7d3998

Header version is 5.6.1; CMake project string is 5.6.0. The commit is the identity.
Do not substitute tag v5.6.0 or a current branch and label the output a reproduction.

## Build layout and commands

Prerequisites: C++17 compiler compatible with this Jolt revision and CMake >=3.20.
The recorded run used Linux x86_64, GCC 13.3.0 and CMake 3.31.6. The included
CMake project forces Release, DOUBLE_PRECISION=ON, disables all compute backends,
object streams, debug renderer, profiler and LTO. Jolt's default enabled x86 SIMD
flags are retained; see provenance_manifest.json. Porting build flags is a new
configuration and should be recorded rather than silently assumed equivalent.

Extract this package to a fresh directory. Download the exact upstream archive
through the URL above, verify its SHA256 with your platform's hash utility, and
extract it under `vendor/JoltPhysics-pin/`, so that this path exists:

    vendor/JoltPhysics-pin/Build/CMakeLists.txt

No credentials or private data are required. The upstream source is not embedded
in the report; its license notice is included as LICENSE_Jolt.txt.

From the root of this package:

```bash
cmake -S experiments -B build
cmake --build build --target cyrus_jolt_probe -j 4
./build/cyrus_jolt_probe > reproduced_results.json
```

The Windows executable path and compiler generator may differ; that environment
was not executed for the report. Compare the output with
`experiments/probe_results.json`. `probe_results_initial.json` records the earlier
run before the off-axis containment / scaled tolerance / active-edge followups
were added. No hidden input geometry is needed: all fixtures are authored in
probe.cpp. The source archive and compiled binary are deliberately not bundled.

## What is actually tested

- Capsule/sphere contact with clear endpoint particles.
- Closed cube versus a wholly contained capsule; shallow and deep soft vertices.
- Closed cube point parity at center and off-axis; open-cube result is untrusted.
- A pinned versus movable vertex inside a sphere.
- Clear guide capsule with a colliding lateral-edge capsule.
- A 0.10-diameter capsule in wall gaps of 0.08 and 0.12.
- Geometrically equivalent crossing queries at scales 1, 1e-3, 1e-5, with default
  and proportionally reduced mCollisionTolerance.
- One root-clamped rod across the sphere, ten updates, five soft substeps.
- World query at origins 0 and 1e6 with matching base offset and double positions.
- Float versus double-before-local coordinate arithmetic.
- One eight-point cuboid hull dropped onto irregular 32-triangle terrain, with
  sleeping and final query residual recorded separately.

The one-rod crossing is a detection diagnostic, not a feasible flexible-detour
benchmark. The narrow-gap rows are contact queries, not a fitting solver. The
rigid result's initial Y is body-origin height, not COM height. No static fitter,
root-orientation spring, full blade evaluator or Max/Cyrus integration was run.

## Acceptance interpretation

Use independent analytic geometry for sphere/capsule truth. Native query failures
at tiny scales and mesh parity ambiguity are preserved as findings, not suppressed
to create a passing test suite. Sleeping and zero update error bits do not certify
final geometric clearance. The numeric residuals are observations from one build;
no cross-platform exact-float or speed claim is made.

For implementation choice, the HTML proposes further gates for root policies,
rest/remaps/reset, feasible multisegment fitting, final-surface validation,
cancellation and host delivery. Those gates remain proposed.

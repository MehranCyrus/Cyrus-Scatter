// Authored exact-pin diagnostic; no Cyrus/Max/renderer/GPU-hair or timing test.
#include <Jolt/Jolt.h>
#include <Jolt/RegisterTypes.h>
#include <Jolt/Core/Factory.h>
#include <Jolt/Core/TempAllocator.h>
#include <Jolt/Core/JobSystemSingleThreaded.h>
#include <Jolt/Physics/PhysicsSystem.h>
#include <Jolt/Physics/Body/BodyCreationSettings.h>
#include <Jolt/Physics/Body/BodyLock.h>
#include <Jolt/Physics/Collision/CollisionDispatch.h>
#include <Jolt/Physics/Collision/CollisionCollectorImpl.h>
#include <Jolt/Physics/Collision/CollidePointResult.h>
#include <Jolt/Physics/Collision/CollideShape.h>
#include <Jolt/Physics/Collision/CollideSoftBodyVertexIterator.h>
#include <Jolt/Physics/Collision/NarrowPhaseQuery.h>
#include <Jolt/Physics/Collision/Shape/BoxShape.h>
#include <Jolt/Physics/Collision/Shape/CapsuleShape.h>
#include <Jolt/Physics/Collision/Shape/ConvexHullShape.h>
#include <Jolt/Physics/Collision/Shape/MeshShape.h>
#include <Jolt/Physics/Collision/Shape/SphereShape.h>
#include <Jolt/Physics/SoftBody/SoftBodyCreationSettings.h>
#include <Jolt/Physics/SoftBody/SoftBodyMotionProperties.h>
#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <cstdlib>
using namespace JPH;
static ShapeRefC Checked(const ShapeSettings::ShapeResult &r){if(r.HasError()){std::cerr<<r.GetError()<<'\n';std::exit(2);}return r.Get();}
struct Query{size_t count;float depth;};
static Query Pair(const Shape *a,const Shape *b,Mat44Arg ta=Mat44::sIdentity(),Mat44Arg tb=Mat44::sIdentity(),float tolerance=1.0e-4f,EActiveEdgeMode edges=EActiveEdgeMode::CollideWithAll){
 AllHitCollisionCollector<CollideShapeCollector> hits;CollideShapeSettings s;s.mBackFaceMode=EBackFaceMode::CollideWithBackFaces;s.mActiveEdgeMode=edges;s.mCollisionTolerance=tolerance;
 CollisionDispatch::sCollideShapeVsShape(a,b,Vec3::sOne(),Vec3::sOne(),ta,tb,SubShapeIDCreator(),SubShapeIDCreator(),s,hits);
 Query q{hits.mHits.size(),0};for(const auto &h:hits.mHits)q.depth=std::max(q.depth,h.mPenetrationDepth);return q;
}
static bool Inside(const Shape *s,Vec3Arg p){AnyHitCollisionCollector<CollidePointCollector> hits;s->CollidePoint(p,SubShapeIDCreator(),hits);return hits.HadHit();}
static std::vector<SoftBodyVertex> SoftPlanes(const Shape *s,const std::vector<Vec3> &ps,float inv=1){
 std::vector<SoftBodyVertex> v(ps.size());for(size_t i=0;i<ps.size();++i){v[i].mPosition=ps[i];v[i].mPreviousPosition=ps[i];v[i].mVelocity=Vec3::sZero();v[i].mInvMass=inv;v[i].ResetCollision();}
 s->CollideSoftBodyVertices(Mat44::sIdentity(),Vec3::sOne(),CollideSoftBodyVertexIterator(v.data()),uint(v.size()),0);return v;
}
static int Violations(const std::vector<SoftBodyVertex>&v,float r){int n=0;for(const auto&p:v)if(p.mCollidingShapeIndex>=0&&p.mCollisionPlane.SignedDistance(p.mPosition)<r)++n;return n;}
static ShapeRefC CubeMesh(bool closed=true){
 const Vec3 v[8]={Vec3(-1,-1,-1),Vec3(1,-1,-1),Vec3(1,1,-1),Vec3(-1,1,-1),Vec3(-1,-1,1),Vec3(1,-1,1),Vec3(1,1,1),Vec3(-1,1,1)};
 const int f[12][3]={{0,3,2},{0,2,1},{4,5,6},{4,6,7},{0,4,7},{0,7,3},{1,2,6},{1,6,5},{0,1,5},{0,5,4},{3,7,6},{3,6,2}};
 TriangleList ts;for(int i=0;i<12;++i){if(!closed&&(i==2||i==3))continue;ts.push_back(Triangle(v[f[i][0]],v[f[i][1]],v[f[i][2]]));}return Checked(MeshShapeSettings(ts).Create());
}
class BroadLayers final:public BroadPhaseLayerInterface{public:uint GetNumBroadPhaseLayers()const override{return 2;}BroadPhaseLayer GetBroadPhaseLayer(ObjectLayer l)const override{return BroadPhaseLayer(uint8(l));}};
class ObjectBroad final:public ObjectVsBroadPhaseLayerFilter{public:bool ShouldCollide(ObjectLayer a,BroadPhaseLayer b)const override{return a!=0||b==BroadPhaseLayer(1);}};
class ObjectPairs final:public ObjectLayerPairFilter{public:bool ShouldCollide(ObjectLayer a,ObjectLayer b)const override{return a!=0||b!=0;}};
struct World{
 BroadLayers layers;ObjectBroad ob;ObjectPairs op;TempAllocatorImpl allocator{16*1024*1024};JobSystemSingleThreaded jobs{cMaxPhysicsJobs};PhysicsSystem system;std::vector<BodyID> bodies;
 World(){system.Init(128,0,512,1024,layers,ob,op);}~World(){auto&bi=system.GetBodyInterface();for(auto id:bodies){bi.RemoveBody(id);bi.DestroyBody(id);}}
 BodyID Add(const BodyCreationSettings&s){auto id=system.GetBodyInterface().CreateAndAddBody(s,s.mMotionType==EMotionType::Static?EActivation::DontActivate:EActivation::Activate);if(id.IsInvalid())std::exit(3);bodies.push_back(id);return id;}
 BodyID AddSoft(const SoftBodyCreationSettings&s){auto id=system.GetBodyInterface().CreateAndAddSoftBody(s,EActivation::Activate);if(id.IsInvalid())std::exit(3);bodies.push_back(id);return id;}
 uint Step(){return uint(system.Update(1.0f/60,1,&allocator,&jobs));}
};
static void PrintVec(Vec3Arg v){std::cout<<'['<<v.GetX()<<','<<v.GetY()<<','<<v.GetZ()<<']';}
int main(){RegisterDefaultAllocator();Factory::sInstance=new Factory();RegisterTypes();std::cout<<std::boolalpha<<std::setprecision(12);
 {
 ShapeRefC sphere=new SphereShape(1),capsule=new CapsuleShape(2,0.05f);Quat along_x=Quat::sFromTo(Vec3::sAxisY(),Vec3::sAxisX());Mat44 cap_tm=Mat44::sRotation(along_x);
 auto crossing=Pair(capsule,sphere,cap_tm);auto endpoints=SoftPlanes(sphere,{Vec3(-2,0,0),Vec3(2,0,0)});
 std::cout<<"{\n\"pin\":\"1b2e77e3c6c09709e5edc79dc208459b8ff32051\",\n\"version\":\""<<JPH_VERSION_MAJOR<<'.'<<JPH_VERSION_MINOR<<'.'<<JPH_VERSION_PATCH<<"\",\n\"double_precision_world\":true,\n\"gpu_compute_enabled\":false,\n\"timing_measured\":false,\n";
 std::cout<<"\"endpoint_crossing\":{\"endpoint_a_inside\":"<<Inside(sphere,Vec3(-2,0,0))<<",\"endpoint_b_inside\":"<<Inside(sphere,Vec3(2,0,0))<<",\"vertex_plane_violations_radius_0_05\":"<<Violations(endpoints,0.05f)<<",\"whole_capsule_hits\":"<<crossing.count<<",\"whole_capsule_depth\":"<<crossing.depth<<"},\n";
 ShapeRefC cube=CubeMesh(),open_cube=CubeMesh(false),small_cap=new CapsuleShape(0.2f,0.05f);auto interior=Pair(small_cap,cube,cap_tm);auto deep=SoftPlanes(cube,{Vec3(0.13f,0.21f,0.17f)});auto shallow=SoftPlanes(cube,{Vec3(0.13f,0.95f,0.17f)});
 std::cout<<"\"mesh_containment\":{\"closed_cube_center_inside\":"<<Inside(cube,Vec3::sZero())<<",\"closed_cube_off_axis_inside\":"<<Inside(cube,Vec3(0.13f,0.21f,0.17f))<<",\"entirely_inside_capsule_surface_hits\":"<<interior.count<<",\"deep_inside_vertex_plane_assigned\":"<<(deep[0].mCollidingShapeIndex>=0)<<",\"shallow_inside_vertex_plane_assigned\":"<<(shallow[0].mCollidingShapeIndex>=0)<<",\"shallow_depth\":"<<shallow[0].mLargestPenetration<<",\"open_cube_point_query_untrusted\":"<<Inside(open_cube,Vec3::sZero())<<"},\n";
 auto pinned=SoftPlanes(sphere,{Vec3(0.2f,0,0)},0),free=SoftPlanes(sphere,{Vec3(0.2f,0,0)},1);
 std::cout<<"\"root_inside\":{\"occupancy\":"<<Inside(sphere,Vec3(0.2f,0,0))<<",\"fixed_vertex_plane_assigned\":"<<(pinned[0].mCollidingShapeIndex>=0)<<",\"movable_vertex_plane_assigned\":"<<(free[0].mCollidingShapeIndex>=0)<<",\"movable_depth\":"<<free[0].mLargestPenetration<<"},\n";
 ShapeRefC thin=new CapsuleShape(0.4f,0.01f);auto guide=Pair(thin,sphere,Mat44::sRotationTranslation(along_x,Vec3(0,1.08f,0)));auto edge=Pair(thin,sphere,Mat44::sRotationTranslation(along_x,Vec3(0,0.92f,0)));
 std::cout<<"\"visible_width\":{\"guide_capsule_hits\":"<<guide.count<<",\"offset_edge_capsule_hits\":"<<edge.count<<",\"half_width\":0.16},\n";
 ShapeRefC wall=new BoxShape(Vec3(0.5f,2,2),0),gap_cap=new CapsuleShape(0.4f,0.05f);std::cout<<"\"narrow_gaps\":[";
 for(int i=0;i<2;++i){float gap=i?0.12f:0.08f;auto a=Pair(gap_cap,wall,Mat44::sIdentity(),Mat44::sTranslation(Vec3(-0.5f-gap/2,0,0)));auto b=Pair(gap_cap,wall,Mat44::sIdentity(),Mat44::sTranslation(Vec3(0.5f+gap/2,0,0)));if(i)std::cout<<',';std::cout<<"{\"gap\":"<<gap<<",\"diameter\":0.1,\"left_hits\":"<<a.count<<",\"right_hits\":"<<b.count<<'}';}std::cout<<"],\n\"scaled_crossing_queries\":[";
 for(int i=0;i<3;++i){float scale=i==0?1:(i==1?0.001f:0.00001f);ShapeRefC sp=new SphereShape(scale),cp=new CapsuleShape(2*scale,0.05f*scale);auto q=Pair(cp,sp,cap_tm);auto tuned=Pair(cp,sp,cap_tm,Mat44::sIdentity(),1.0e-4f*scale);if(i)std::cout<<',';std::cout<<"{\"scale\":"<<scale<<",\"hits\":"<<q.count<<",\"depth\":"<<q.depth<<",\"scaled_collision_tolerance_hits\":"<<tuned.count<<",\"scaled_collision_tolerance_depth\":"<<tuned.depth<<'}';}std::cout<<"],\n";
 Ref<SoftBodySharedSettings> rest=new SoftBodySharedSettings;rest->mVertices.push_back(SoftBodySharedSettings::Vertex(Float3(-2,0,0),Float3(0,0,0),0));rest->mVertices.push_back(SoftBodySharedSettings::Vertex(Float3(2,0,0)));rest->mRodStretchShearConstraints.push_back(SoftBodySharedSettings::RodStretchShear(0,1));rest->CalculateRodProperties();float rod_inv=rest->mRodStretchShearConstraints[0].mInvMass;rest->Optimize();
 {World w;w.system.SetGravity(Vec3::sZero());w.Add(BodyCreationSettings(sphere,RVec3::sZero(),Quat::sIdentity(),EMotionType::Static,0));SoftBodyCreationSettings s(rest,RVec3::sZero(),Quat::sIdentity(),1);s.mUpdatePosition=false;s.mGravityFactor=0;s.mAllowSleeping=false;s.mVertexRadius=0.05f;s.mNumIterations=5;auto id=w.AddSoft(s);uint errors=0;for(int i=0;i<10;++i)errors|=w.Step();BodyLockRead lock(w.system.GetBodyLockInterface(),id);const auto*mp=static_cast<const SoftBodyMotionProperties*>(lock.GetBody().GetMotionProperties());Vec3 a=mp->GetVertex(0).mPosition,b=mp->GetVertex(1).mPosition;float shift=std::max((a-Vec3(-2,0,0)).Length(),(b-Vec3(2,0,0)).Length());std::cout<<"\"stock_rod_crossing_update\":{\"steps\":10,\"dt\":0.0166666666667,\"soft_substeps\":5,\"first_rod_derived_inverse_mass\":"<<rod_inv<<",\"max_endpoint_displacement\":"<<shift<<",\"update_error_bits\":"<<errors<<",\"final_a\":";PrintVec(a);std::cout<<",\"final_b\":";PrintVec(b);std::cout<<"},\n";}
 std::cout<<"\"large_coordinate_query\":[";
 for(int i=0;i<2;++i){double offset=i?1000000.0:0;World w;RVec3 origin(offset,offset,offset);w.Add(BodyCreationSettings(sphere,origin,Quat::sIdentity(),EMotionType::Static,0));AllHitCollisionCollector<CollideShapeCollector> hits;CollideShapeSettings s;w.system.GetNarrowPhaseQuery().CollideShape(capsule,Vec3::sOne(),RMat44::sRotationTranslation(along_x,origin),s,origin,hits);if(i)std::cout<<',';std::cout<<"{\"origin\":"<<offset<<",\"base_offset_matches_origin\":true,\"hits\":"<<hits.mHits.size()<<'}';}
 volatile float large_f=1000000.0f,small_f=0.001f;double large_d=1000000.0,small_d=0.001;std::cout<<"],\n\"coordinate_conversion_arithmetic\":{\"float_world_delta\":"<<float((large_f+small_f)-large_f)<<",\"double_before_local_delta\":"<<((large_d+small_d)-large_d)<<"},\n";
 {World w;PhysicsSettings ps=w.system.GetPhysicsSettings();ps.mPenetrationSlop=0.001f;ps.mSpeculativeContactDistance=0.01f;w.system.SetPhysicsSettings(ps);TriangleList ts;auto point=[](int x,int z){float xx=float(x-2),zz=float(z-2);return Vec3(xx,0.10f*std::sin(1.3f*xx)*std::cos(0.9f*zz),zz);};for(int z=0;z<4;++z)for(int x=0;x<4;++x){Vec3 a=point(x,z),b=point(x+1,z),c=point(x+1,z+1),d=point(x,z+1);ts.push_back(Triangle(a,c,b));ts.push_back(Triangle(a,d,c));}ShapeRefC terrain=Checked(MeshShapeSettings(ts).Create());w.Add(BodyCreationSettings(terrain,RVec3::sZero(),Quat::sIdentity(),EMotionType::Static,0));Array<Vec3> pts;for(int i=0;i<8;++i)pts.push_back(Vec3((i&1)?0.22f:-0.19f,(i&2)?0.14f:-0.16f,(i&4)?0.18f:-0.17f));ConvexHullShapeSettings hs(pts,0.01f);ShapeRefC hull=Checked(hs.Create());BodyCreationSettings s(hull,RVec3(0,1.5,0),Quat::sEulerAngles(Vec3(0.2f,0.35f,0.13f)),EMotionType::Dynamic,1);s.mFriction=0.6f;s.mRestitution=0;auto id=w.Add(s);auto&bi=w.system.GetBodyInterface();w.system.OptimizeBroadPhase();uint steps=0,errors=0;while(bi.IsActive(id)&&steps<600){errors|=w.Step();++steps;}RVec3 center=bi.GetCenterOfMassPosition(id);Quat rotation=bi.GetRotation(id);auto q=Pair(hull,terrain,Mat44::sRotationTranslation(rotation,Vec3(center)));auto active=Pair(hull,terrain,Mat44::sRotationTranslation(rotation,Vec3(center)),Mat44::sIdentity(),1.0e-4f,EActiveEdgeMode::CollideOnlyWithActive);std::cout<<"\"rigid_hull_on_irregular_mesh\":{\"terrain_triangles\":32,\"hull_input_points\":8,\"start_y\":1.5,\"gravity_y\":-9.81,\"dt\":0.0166666666667,\"steps\":"<<steps<<",\"sleeping\":"<<!bi.IsActive(id)<<",\"update_error_bits\":"<<errors<<",\"final_com\":";PrintVec(Vec3(center));std::cout<<",\"final_speed\":"<<bi.GetLinearVelocity(id).Length()<<",\"query_max_penetration\":"<<q.depth<<",\"query_active_edges_only_max_penetration\":"<<active.depth<<",\"penetration_slop\":0.001,\"speculative_distance\":0.01}\n}\n";}
 }
 UnregisterTypes();delete Factory::sInstance;Factory::sInstance=nullptr;return 0;
}

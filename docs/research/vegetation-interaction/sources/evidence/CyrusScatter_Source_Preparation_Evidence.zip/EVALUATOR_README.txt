CyrusScatter source-preparation study, 2026-10-24.
Run with Python 3 standard library: python reference_evaluator.py
Ten arithmetic checks; no automatic capture, fitting, Max, renderer or performance test.
For geometry representation checks, run the included audit_assets.py in its bundled directory.
The Kenney files are public CC0 assets; original license is included.
Preparation and delivery architecture in the HTML are proposals.

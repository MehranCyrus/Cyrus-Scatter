#!/usr/bin/env python3
"""Draw exact mesh projections as SVG diagrams. This is not a DCC render test."""
import html
import json
from pathlib import Path
from audit_assets import ROOT, obj_read


def components(points, faces):
    parent=list(range(len(points)))
    def find(a):
        while parent[a]!=a:
            parent[a]=parent[parent[a]];a=parent[a]
        return a
    for f in faces:
        for a in f[1:]:
            parent[find(a)]=find(f[0])
    ids={v:i for i,v in enumerate(sorted({find(i) for f in faces for i in f}))}
    return [ids[find(f[0])] for f in faces]


def svg_header(width,height,title,desc):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img">',
            f'<title>{html.escape(title)}</title><desc>{html.escape(desc)}</desc>',
            '<style>text{font-family:Arial,Helvetica,sans-serif;fill:#17332e}.title{font-size:23px;font-weight:700}.label{font-size:17px;font-weight:700}.sub{font-size:13px;fill:#425a55}.note{font-size:12px;fill:#526a64}</style>',
            f'<rect width="{width}" height="{height}" rx="16" fill="#f7faf7"/>']


def panel(svg, x,y,w,h,points,faces,title,subtitle,up='y',colors=None):
    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="white" stroke="#dce8df"/>')
    svg.append(f'<text class="label" x="{x+18}" y="{y+29}">{html.escape(title)}</text>')
    svg.append(f'<text class="sub" x="{x+18}" y="{y+49}">{html.escape(subtitle)}</text>')
    q = [(p[0]*.85-p[2]*.55,p[1]+p[0]*.25+p[2]*.20) if up=='y'
         else (p[0]*.85-p[1]*.55,p[2]+p[0]*.13+p[1]*.20) for p in points]
    lo=[min(p[a] for p in q) for a in range(2)]
    hi=[max(p[a] for p in q) for a in range(2)]
    scale=min((w-48)/(hi[0]-lo[0]),(h-83)/(hi[1]-lo[1]))
    sx=x+w*.5-(hi[0]+lo[0])*.5*scale
    sy=y+66+(h-83)*.5+(hi[1]+lo[1])*.5*scale
    coords=[(sx+p[0]*scale,sy-p[1]*scale) for p in q]
    color_ids=components(points,faces) if colors is None else colors
    for f,c in zip(faces,color_ids):
        coords_str=' '.join(f'{coords[i][0]:.2f},{coords[i][1]:.2f}' for i in f)
        hue=(c*137.508+148)%360
        svg.append(f'<polygon points="{coords_str}" fill="hsl({hue:.1f},50%,48%)" fill-opacity="0.88" stroke="#f7faf7" stroke-width="0.65"/>')


def main():
    svg=svg_header(1080,720,'One source, different component counts',
        'Exact orthographic mesh projections of two Kenney public grass sources. Left uses OBJ position indices. Right uses expanded OBJ position, texture-coordinate and normal indices. Colors distinguish connected components; opposite-winding duplicate faces overlap. No botanical IDs or roots are inferred.')
    svg.append('<text class="title" x="26" y="36">One source, different component counts</text>')
    svg.append('<text class="sub" x="26" y="59">Exact mesh projections · component colors · no application or renderer test</text>')
    for row,name in enumerate(('grass','grass_leafs')):
        m=obj_read(ROOT/'public_assets'/(name+'.obj'))
        logical=9 if name=='grass' else 6
        render=66 if name=='grass' else 24
        panel(svg,24,79+row*285,504,270,m['positions'],m['faces'],name+'.obj: position topology',
              f'{len(m["positions"])} positions · {logical} components · {len(m["faces"])} triangles')
        panel(svg,552,79+row*285,504,270,m['render_positions'],m['render_faces'],'Same mesh: render-vertex topology',
              f'{len(m["render_positions"])} vertices · {render} components · same triangle count')
    svg.append('<text class="note" x="26" y="677">Colors are graph components, not confirmed blades. Opposite-winding copies overlap in this projection.</text>')
    svg.append('<text class="note" x="26" y="698">The shipped GLB reproduces the expanded counts. Kenney Nature Kit, CC0 · audit_assets.py records source hashes.</text>')
    svg.append('</svg>');(ROOT/'public_asset_topology.svg').write_text('\n'.join(svg))
    svg=svg_header(1080,840,'Synthetic preparation fixtures','Six explicitly authored synthetic mesh fixtures illustrate connectivity and semantic ambiguity. They are not scan datasets or application fitting tests.')
    svg.append('<text class="title" x="24" y="35">Synthetic topology fixtures</text>')
    names=['single_blade','disconnected_clump','shared_base','uv_seam','crossed_cards','irregular_sheet']
    titles=['Segmented blade','Disconnected clump','Welded shared base','UV-split blade','Crossed cards','Irregular sheet']
    notes=['1 component; 1 authored blade','3 components; 3 authored blades','1 component; 3 authored blade regions','1 logical component; 16 render islands','2 cards; alpha occupancy unspecified','1 component; no botanical semantics']
    for idx,(name,title,note) in enumerate(zip(names,titles,notes)):
        m=json.loads((ROOT/'fixtures'/(name+'.json')).read_text())
        colors=list(range(len(m['faces']))) if name=='uv_seam' else None
        panel(svg,24+(idx%3)*352,58+(idx//3)*371,328,354,m['positions'],m['faces'],title,note,'z',colors)
    svg.append('<text class="note" x="24" y="825">Authored examples only. Irregular sheet is not a real scan; crossed cards have no sampled opacity texture.</text>')
    svg.append('</svg>');(ROOT/'synthetic_fixtures.svg').write_text('\n'.join(svg))


if __name__=='__main__':
    main()

# Inspectable source-preparation evidence

**Scope:** Two public Kenney vegetation sources were downloaded and inspected. Seven synthetic mesh fixtures were generated, and seven Python topology/arithmetic checks passed. Nothing in this evidence set executes Houdini, tyFlow, 3ds Max, a production renderer, simulation, collision fitting, guide extraction, or a performance benchmark. The diagrams are direct projections of mesh coordinates, not application render tests.

## Evidence labels

- **D — Documented:** Statements on the official creator page, the included license, or the glTF specification.
- **I — Inspected:** File structure, values, topology, and metadata actually read from the downloaded OBJ/GLB files.
- **X — Executed:** Assertions run by `audit_assets.py`, recorded in `fixture_audit.json`.
- **P — Proposed:** Preparation policies recommended from those observations. They remain product-design proposals.

## 1. Public geometry and reproducible provenance

**D:** Kenney's official [Nature Kit page](https://kenney.nl/assets/nature-kit) identifies a 3D asset pack and CC0 license. Its Download / Continue without donating link resolves to the following archive; no login, license acceptance, purchase, or subscription was used:

`https://kenney.nl/media/pages/assets/nature-kit/37ac38a37b-1677698939/kenney_nature-kit.zip`

**I:** Downloaded 2026-10-24. Archive size **10,537,521 bytes**. SHA-256:

`fa7974a0d342bfe63c38664ba9f8ec1a4aab8ea25f099bdc56870e33588c4d9d`

The web page's update list says “1.0 Released in 2020”; the downloaded `License.txt` labels the pack **Nature Kit (2.1)** and says CC0. Preserve that discrepancy in provenance rather than synthesizing a single release history. The actual file hashes identify the inspected input. The assets' creator is Kenney.

The unmodified inspected files are:

| Archive member | Bytes | SHA-256 |
|---|---:|---|
| `Models/OBJ format/grass.obj` | 11,590 | `a444b815fa29d2278e3fcac03ef79e52d7232a845f65dce2443075d2b294c74e` |
| `Models/GLTF format/grass.glb` | 11,496 | `260e41d3e5f2472492ed7b475c5b92a30b13ce2bad408535b5ff50574d4575e7` |
| `Models/OBJ format/grass_leafs.obj` | 4,197 | `43d88cee97274d39d9992d1a1ce5f396150037f91cac19e0bc2eb03831366b8c` |
| `Models/GLTF format/grass_leafs.glb` | 4,608 | `8bc4c0b17c2e64c34e1acbf7c4a2fd8c04cfcd7155328e61767887b2ced112c7` |

The two accompanying MTL files and original license are also retained in `public_assets/`. These are deliberately small stylized sources, not photoreal scans, a representative sample of the user's library, or performance test assets.

## 2. The useful real-file finding: render vertices are not botanical parts

**I/X:** The same source has substantially different connected-component counts depending on which indices are used:

| Source | OBJ position vertices | OBJ triangles | Position-index components | Expanded render vertices | Render-index components | Shipped GLB agrees with expanded counts? |
|---|---:|---:|---:|---:|---:|---|
| `grass` | 84 | 132 | 9 | 264 | 66 | Yes |
| `grass_leafs` | 30 | 36 | 6 | 84 | 24 | Yes |

“Expanded render vertex” means one vertex for each distinct **(position index, UV index, normal index)** tuple in the OBJ face corners. The original geometric positions and faces are retained. These counts match the shipped GLB's position accessor, triangle indices, and connected components. This is count agreement, not a claim that an exact cross-format vertex mapping was recovered. OBJ/GLB axes and scene transforms need their own import policy: the GLB mesh node includes a local Y translation of −0.05. The audit counts local mesh data; that translation cannot change connectivity.

The audit does **not** claim that 9 or 6 components are 9 or 6 botanical blades. No root mask, guide hierarchy, explicit blade IDs, or semantic botanical annotations were found in the inspected OBJ/GLB. A plausible interpretation can be previewed for an artist, but topology alone does not certify it.

The two GLBs each have one material and `alphaMode: OPAQUE`; these are not inspected examples of texture-masked vegetation cards. Both GLBs contain positions, normals, and UVs. The original OBJ retains face-corner UV/normal indices independently of geometric position indices.

### Two-sided geometry is another topology trap

**I/X:** Every OBJ triangle has exactly one mate with the same three **position IDs** and opposite winding. This test groups triangle position-ID sets and verifies the two permutations have opposite parity. It does not group approximately coincident positions. Raw position topology consequently reports 57 edges with more than two incident faces for `grass` and 12 for `grass_leafs`. Those are true raw counts; interpreting them as corrupt or branched botanical structure would overlook this explicit two-sided construction.

An **analysis-only** graph taking one representative of each pair has 66 and 18 triangles, respectively; it has no edge with more than two incident faces and preserves the 9 and 6 connected-component counts. No original face, UV, material, normal, or file is deleted or rewritten. Do not bake this diagnostic simplification into delivered geometry without an intentional material/sidedness conversion.

**P:** The preparation importer should keep a source-topology layer distinct from render-corner vertices, flag explicit opposite-winding pairs, and preserve a reversible render-to-logical correspondence. When only a render mesh is available, coordinate welding is an uncertain hypothesis to preview and confirm. A UV or normal split is not a blade boundary, and coincident positions are not proof of shared identity.

## 3. Synthetic counterexamples

The fixture generator stores positions, faces, UVs, root IDs where authored, and explicit author-supplied semantic counts in JSON. These semantic counts are **ground truth created for the fixture**, not the output of a recognition algorithm. OBJ copies make the geometry inspectable in another application.

| Fixture | Position vertices | Triangles | Logical components | What is actually established |
|---|---:|---:|---:|---|
| Segmented blade | 18 | 16 | 1 | Authored rest bend, width taper, and twist with a known root edge. |
| Disconnected clump | 54 | 48 | 3 | Three known independent blades; connected components agree in this controlled case. |
| Welded/shared-base clump | 60 | 58 | 1 | Three authored blade regions joined to one manifold base patch; components cannot recover those regions. |
| UV-seam blade | 18 | 16 | 1 | Same geometric blade, but every triangle has separate UV IDs; expanded render topology has 48 vertices and 16 islands. |
| Crossed cards | 8 | 4 | 2 | Two crossing planes are separate topology; blade occupancy in an opacity texture is unspecified. |
| Irregular sheet | 81 | 128 | 1 | A deterministic irregular triangulated patch; no root/blade semantics are asserted. **This is not a real scan.** |
| Coincident independent blades | 36 | 32 | 2 | Two authored blades occupy identical positions but have independent IDs; exact coordinate welding collapses them incorrectly to one component. |

The crossed-card fixture does not sample an opacity texture, so it cannot prove how many blades are painted, where their roots are, whether their alpha silhouettes touch, or whether bending the polygon plane matches the painted foliage. The irregular sheet is a stress case for assumptions about topology; it proves nothing about actual scan reconstruction quality. No renderer proxy file was downloaded or opened.

## 4. Executed checks and limits

Run:

```sh
python3 source_preparation/audit_assets.py
python3 source_preparation/make_asset_figures.py
```

Both scripts use only Python's standard library. The audit reads the supplied public assets, regenerates the synthetic fixtures deterministically, and overwrites the audit JSON with its current results. It does not need network access. The diagram script writes SVGs; PNGs are convenience previews.

**X — Seven checks passed:**

1. Splitting UVs and then following retained logical IDs recovers original triangle logical IDs, face-corner positions, and UV values exactly.
2. The UV-split single blade has 16 render-index components but one logical component.
3. The shared-base fixture has one component and no edge with more than two incident faces, while the fixture author defines three blade regions.
4. The two coincident independent blades have two components; exact coordinate merging collapses them to one.
5. None of the seven authored fixtures has a zero-area triangle.
6. The `grass` OBJ render expansion agrees with shipped GLB vertex, triangle, and component counts; all original OBJ triangles have opposite-winding mates.
7. The corresponding checks also pass for `grass_leafs`.

These are narrow representation checks. They do not validate automatic root detection, centerlines, blade membership, collision handling, deformation quality, normal reconstruction, material parity, export parity, memory at thousands of placements, or runtime performance. No preparation times, benchmarks, or artist effort measurements were recorded.

## 5. Proposed use in the Cyrus asset contract

**P:** Prefer an editable source with stable logical position IDs, face-corner UV/normal mapping, declared units/up axis, and one explicitly confirmed root region. Save the preparation once against the immutable source revision. Public sources like these can provide useful candidate strips after an analysis-only two-sided classification; the artist must confirm which parts are blades and which end is rooted.

For disconnected clumps, connected components are a candidate segmentation method, contingent on semantic review. For welded clumps, ask for branch labels, guide assignments, or a base region before offering independent-blade fitting. For split render geometry, use provenance if available and show ambiguity if reconstructing topology. For opacity cards, offer whole-card/clump bending as a clearly bounded level; visible blade-by-blade contact requires geometry or authored guides/occupancy information that the plain card does not contain. For dense scans, use an authored skeleton/cage or reviewed segmentation; the synthetic irregular sheet is not evidence that automatic extraction succeeds. For opaque proxies, require documented render-mesh access or an editable preparation source with a verified correspondence; a preview mesh alone cannot establish that mapping.

Minimum audit fields suggested by the evidence: source/file hash; import axis/unit policy; position and render vertex counts; duplicate opposite-winding pairs; UV/normal seam correspondence; raw versus analysis component counts; nonmanifold/degenerate diagnostics; root/guide semantic provenance; ambiguity status; material/sidedness flags; topology/rest-position/binding revision; and an explicit “no geometry access” status for proxies.

## Files for the report

- `fixture_audit.json`: full machine-readable results and hashes.
- `audit_assets.py`: reproducible executed audit.
- `make_asset_figures.py`: SVG generation from inspected mesh coordinates.
- `public_asset_topology.svg`: visually checked 2×2 comparison of the two public sources; colors represent graph components only.
- `synthetic_fixtures.svg`: six synthetic examples, clearly labelled.
- `fixtures/*.json` and `fixtures/*.obj`: authored fixture data, including seam and identity counterexamples.
- `assets_sources.json`: sources and evidence identifiers A01–A05.


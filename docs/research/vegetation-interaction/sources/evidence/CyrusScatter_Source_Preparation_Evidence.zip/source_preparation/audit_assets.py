#!/usr/bin/env python3
"""Reproducible topology audit; no DCC, fitting, renderer, or speed test.

Run from any directory: python3 /path/to/source_preparation/audit_assets.py
The two unmodified Kenney OBJ/GLB sources must be in public_assets/. Synthetic
fixtures are generated deterministically. Only Python's standard library is used.
"""
from __future__ import annotations
import collections
import hashlib
import json
import math
from pathlib import Path
import random
import struct

ROOT = Path(__file__).resolve().parent


def digest(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def topology(points, faces):
    parent = list(range(len(points)))
    def find(v):
        while parent[v] != v:
            parent[v] = parent[parent[v]]
            v = parent[v]
        return v
    def join(a, b):
        a, b = find(a), find(b)
        if a != b:
            parent[b] = a
    used = set()
    edge_faces = collections.Counter()
    for f in faces:
        used.update(f)
        for a, b in zip(f, f[1:] + f[:1]):
            join(a, b)
            edge_faces[tuple(sorted((a, b)))] += 1
    groups = collections.defaultdict(list)
    for v in sorted(used):
        groups[find(v)].append(v)
    degenerate = 0
    for f in faces:
        p, q, r = [points[i] for i in f[:3]]
        a, b = [q[i]-p[i] for i in range(3)], [r[i]-p[i] for i in range(3)]
        cross = (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
        if sum(x*x for x in cross) <= 1e-24:
            degenerate += 1
    return {
        "position_count": len(points), "referenced_positions": len(used),
        "faces": len(faces), "triangles": sum(len(f)-2 for f in faces),
        "connected_components": len(groups),
        "component_vertex_counts": sorted((len(g) for g in groups.values()), reverse=True),
        "edges": len(edge_faces), "boundary_edges": sum(n == 1 for n in edge_faces.values()),
        "edges_with_more_than_two_incident_faces": sum(n > 2 for n in edge_faces.values()),
        "degenerate_triangles": degenerate,
        "bbox_min": [min(p[i] for p in points) for i in range(3)],
        "bbox_max": [max(p[i] for p in points) for i in range(3)]
    }


def unique_faces(faces):
    """Analysis only: collapse triangles with same position IDs, either winding."""
    seen, result = set(), []
    for face in faces:
        key = tuple(sorted(face))
        if key not in seen:
            seen.add(key)
            result.append(face)
    return result


def obj_read(path):
    ps, uvs, normals, faces, corner_faces, materials = [], [], [], [], [], []
    current_material = None
    for line in path.read_text().splitlines():
        p = line.split()
        if not p or p[0].startswith('#'):
            continue
        if p[0] == 'v':
            ps.append(list(map(float, p[1:4])))
        elif p[0] == 'vt':
            uvs.append(list(map(float, p[1:3])))
        elif p[0] == 'vn':
            normals.append(list(map(float, p[1:4])))
        elif p[0] == 'usemtl':
            current_material = p[1]
        elif p[0] == 'f':
            corners = []
            for token in p[1:]:
                parts = token.split('/')
                corners.append(tuple(int(x)-1 if x else None for x in parts))
            corner_faces.append(corners)
            faces.append([c[0] for c in corners])
            materials.append(current_material)
    keys, render_positions, render_faces = {}, [], []
    for cf in corner_faces:
        rf = []
        for c in cf:
            if c not in keys:
                keys[c] = len(keys)
                render_positions.append(ps[c[0]])
            rf.append(keys[c])
        render_faces.append(rf)
    return {"positions": ps, "uvs": uvs, "normals": normals, "faces": faces,
            "corners": corner_faces, "render_positions": render_positions,
            "render_faces": render_faces, "materials": sorted(set(materials))}


def glb_read(path):
    data = path.read_bytes()
    magic, version, length = struct.unpack_from('<III', data)
    assert magic == 0x46546C67 and version == 2 and length == len(data)
    offset, doc, binary = 12, None, None
    while offset < len(data):
        size, kind = struct.unpack_from('<II', data, offset)
        chunk = data[offset+8:offset+8+size]
        if kind == 0x4E4F534A:
            doc = json.loads(chunk)
        elif kind == 0x004E4942:
            binary = chunk
        offset += size+8
    def accessor(index):
        a = doc['accessors'][index]
        assert not a.get('sparse') and not a.get('normalized')
        view = doc['bufferViews'][a['bufferView']]
        n = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[a['type']]
        c = {5126: 'f', 5125: 'I', 5123: 'H', 5121: 'B'}[a['componentType']]
        fmt = '<'+c*n
        stride = view.get('byteStride', struct.calcsize(fmt))
        start = view.get('byteOffset', 0)+a.get('byteOffset', 0)
        return [list(struct.unpack_from(fmt, binary, start+i*stride)) for i in range(a['count'])]
    assert len(doc['meshes']) == 1 and len(doc['meshes'][0]['primitives']) == 1
    primitive = doc['meshes'][0]['primitives'][0]
    assert primitive.get('mode', 4) == 4
    ps = accessor(primitive['attributes']['POSITION'])
    ids = [x[0] for x in accessor(primitive['indices'])]
    fs = [ids[i:i+3] for i in range(0, len(ids), 3)]
    return {"positions": ps, "faces": fs, "document": doc}


def strip(name, origin=(0., 0., 0.), angle=0., segments=8):
    ps, uv, faces = [], [], []
    for i in range(segments+1):
        t = i/segments
        width = .16*(1-.82*t)
        twist = .7*t
        cx, cy, cz = .26*t*t, .08*math.sin(t*math.pi), t
        for side in (-1, 1):
            x = cx + side*width*.5*math.cos(twist)
            y = cy + side*width*.5*math.sin(twist)
            ps.append([origin[0]+math.cos(angle)*x-math.sin(angle)*y,
                       origin[1]+math.sin(angle)*x+math.cos(angle)*y, origin[2]+cz])
            uv.append([(side+1)/2, t])
    for i in range(segments):
        a = 2*i
        faces.extend([[a, a+1, a+2], [a+1, a+3, a+2]])
    return {"name": name, "positions": ps, "faces": faces, "uvs": uv,
            "face_uvs": [f[:] for f in faces], "root_position_ids": [0, 1],
            "authored_blade_count": 1, "note": "Synthetic segmented blade with authored rest bend and twist."}


def merged(name, meshes):
    result = {"name": name, "positions": [], "faces": [], "uvs": [], "face_uvs": [],
              "root_position_ids": [], "authored_blade_count": len(meshes), "blade_vertex_ids": []}
    for m in meshes:
        p, u = len(result['positions']), len(result['uvs'])
        result['positions'].extend(m['positions'])
        result['uvs'].extend(m['uvs'])
        result['faces'].extend([[v+p for v in f] for f in m['faces']])
        result['face_uvs'].extend([[v+u for v in f] for f in m['face_uvs']])
        result['root_position_ids'].extend([v+p for v in m['root_position_ids']])
        result['blade_vertex_ids'].append(list(range(p, len(result['positions']))))
    return result


def shared_base():
    xs = [-.7, -.5, -.1, .1, .5, .7]
    ps = [[x, 0., z] for z in (0., .12) for x in xs]
    fs = []
    for i in range(5):
        fs.extend([[i, i+1, i+6], [i+1, i+7, i+6]])
    memberships = []
    for k in range(3):
        rows = [[6+2*k, 7+2*k]]
        for i in range(1, 9):
            t = i/8
            center = (xs[2*k]+xs[2*k+1])*.5 + (k-1)*.25*t*t
            rows.append([len(ps), len(ps)+1])
            ps.extend([[center+s*.1*(1-.8*t), .12*math.sin(t*math.pi)*(k-1), .12+t] for s in (-1,1)])
        for a, b in zip(rows, rows[1:]):
            fs.extend([[a[0], a[1], b[0]], [a[1], b[1], b[0]]])
        memberships.append([p for row in rows for p in row])
    uv = [[p[0],p[2]] for p in ps]
    return {"name": "shared_base", "positions": ps, "faces": fs, "uvs": uv,
            "face_uvs": [f[:] for f in fs], "root_position_ids": list(range(6)),
            "authored_blade_count": 3, "blade_vertex_ids": memberships,
            "base_vertex_ids": list(range(12)),
            "note": "Three authored blade regions welded to one manifold base patch; one connected component."}


def crossed_cards():
    ps = [[-.45,0,0],[.45,0,0],[-.45,0,1],[.45,0,1],
          [0,-.45,0],[0,.45,0],[0,-.45,1],[0,.45,1]]
    fs = [[0,1,2],[1,3,2],[4,5,6],[5,7,6]]
    return {"name":"crossed_cards", "positions":ps, "faces":fs,
            "uvs":[[0,0],[1,0],[0,1],[1,1]]*2, "face_uvs":[f[:] for f in fs],
            "root_position_ids":[0,1,4,5], "authored_card_count":2,
            "authored_blade_count":None,
            "note":"Synthetic crossed cards; alpha occupancy intentionally unspecified. Cards are not botanical blade IDs."}


def irregular_sheet():
    rng = random.Random(716)
    ps, fs = [], []
    for j in range(9):
        for i in range(9):
            x, y = i/8-.5, j/8
            ps.append([x+(.025*rng.uniform(-1,1) if 0<i<8 else 0),
                       .04*rng.uniform(-1,1)+.12*math.sin(x*4)*math.sin(y*3),
                       y+(.02*rng.uniform(-1,1) if 0<j<8 else 0)])
    for j in range(8):
        for i in range(8):
            a = 9*j+i
            if rng.random()<.5:
                fs.extend([[a,a+1,a+9],[a+1,a+10,a+9]])
            else:
                fs.extend([[a,a+1,a+10],[a,a+10,a+9]])
    return {"name":"irregular_sheet", "positions":ps, "faces":fs,
            "uvs":[[p[0]+.5,p[2]] for p in ps], "face_uvs":[f[:] for f in fs],
            "root_position_ids":[], "authored_blade_count":None,
            "note":"Synthetic irregular triangulated patch; NOT scanned vegetation. No root/blade semantics are asserted."}


def write_fixture(m):
    folder = ROOT/'fixtures'
    folder.mkdir(exist_ok=True)
    name = m['name']
    (folder/(name+'.json')).write_text(json.dumps(m,indent=2)+'\n')
    lines = ['# Synthetic topology fixture; no DCC fitting or rendering tested.']
    lines += ['v '+' '.join(f'{x:.10g}' for x in p) for p in m['positions']]
    lines += ['vt '+' '.join(f'{x:.10g}' for x in p) for p in m['uvs']]
    lines += ['f '+' '.join(f'{p+1}/{u+1}' for p,u in zip(f,uf)) for f,uf in zip(m['faces'],m['face_uvs'])]
    (folder/(name+'.obj')).write_text('\n'.join(lines)+'\n')


def split_at_uv(m):
    keys, positions, faces, logical, uvs = {}, [], [], [], []
    for f, uvf in zip(m['faces'],m['face_uvs']):
        rf = []
        for p, u in zip(f,uvf):
            key = (p,u)
            if key not in keys:
                keys[key] = len(keys)
                positions.append(m['positions'][p]); logical.append(p); uvs.append(m['uvs'][u])
            rf.append(keys[key])
        faces.append(rf)
    return positions, faces, logical, uvs


def coordinate_merge_diagnostic(m):
    lookup, ps, indices = {}, [], []
    for p in m['positions']:
        key = tuple(p)
        if key not in lookup:
            lookup[key] = len(ps); ps.append(p)
        indices.append(lookup[key])
    return topology(ps, [[indices[i] for i in f] for f in m['faces']])


def main():
    a = strip('single_blade')
    clump = merged('disconnected_clump', [strip('b', origin=(x, y, 0), angle=angle)
                            for x,y,angle in [(-.4,0,-.7),(0,.12,.1),(.4,0,1.0)]])
    clump['note'] = 'Three authored independent blades; IDs and roots are fixture ground truth, not inferred from topology.'
    seam = json.loads(json.dumps(a)); seam['name']='uv_seam'
    seam['uvs'],seam['face_uvs']=[],[]
    for face_index,f in enumerate(seam['faces']):
        seam['face_uvs'].append(list(range(len(seam['uvs']),len(seam['uvs'])+3)))
        seam['uvs'].extend([[a['uvs'][v][0]+2*(face_index%4),
                             a['uvs'][v][1]+2*(face_index//4)] for v in f])
    seam['note']='Same geometric blade as single_blade; separate UV IDs and displaced UV islands for every triangle. Retained provenance enables exact reassembly.'
    coincident = merged('coincident_independent', [a, a])
    coincident['note']='Two exactly coincident authored blades with distinct position IDs; proximity welding falsely merges their identities.'
    fixtures=[a,clump,shared_base(),seam,crossed_cards(),irregular_sheet(),coincident]
    report={"scope":"Executed Python file/topology/arithmetic inspection only. No Houdini, tyFlow, 3ds Max, renderer, simulation, fitting quality, or performance test.",
            "date":"2026-10-24", "public_assets":[], "synthetic_fixtures":[], "checks":[]}
    for m in fixtures:
        write_fixture(m)
        ps, fs, correspondence, uv = split_at_uv(m)
        report['synthetic_fixtures'].append({"id":m['name'], "authored_blade_count":m['authored_blade_count'],
            "note":m['note'], "logical_topology":topology(m['positions'],m['faces']),
            "render_topology_after_uv_split":topology(ps,fs),
            "root_position_ids":m['root_position_ids']})
    ps, fs, logical, uv = split_at_uv(seam)
    recovered = [[logical[i] for i in f] for f in fs]
    assert recovered == seam['faces']
    assert all(ps[rv] == seam['positions'][lv] for f,rf in zip(seam['faces'],fs) for lv,rv in zip(f,rf))
    assert all(uv[rv] == seam['uvs'][ui] for uf,rf in zip(seam['face_uvs'],fs) for ui,rv in zip(uf,rf))
    assert topology(ps,fs)['connected_components']==16
    assert topology(seam['positions'],recovered)['connected_components']==1
    assert topology(coincident['positions'],coincident['faces'])['connected_components']==2
    assert coordinate_merge_diagnostic(coincident)['connected_components']==1
    assert topology(fixtures[2]['positions'],fixtures[2]['faces'])['connected_components']==1
    assert topology(fixtures[2]['positions'],fixtures[2]['faces'])['edges_with_more_than_two_incident_faces']==0
    assert all(topology(m['positions'],m['faces'])['degenerate_triangles']==0 for m in fixtures)
    report['checks'] += [
        {"name":"UV split reassembly preserves triangle logical IDs, face-corner positions, and UV values exactly", "result":"PASS"},
        {"name":"UV-split single blade has 16 render-index components but 1 logical component", "result":"PASS"},
        {"name":"Shared manifold base has 1 component but fixture author defines 3 blade regions", "result":"PASS"},
        {"name":"Two coincident independent blades have 2 components; exact coordinate merge collapses to 1", "result":"PASS"},
        {"name":"All seven authored fixtures contain no zero-area triangles", "result":"PASS"}]
    for name in ('grass','grass_leafs'):
        path=ROOT/'public_assets'/(name+'.obj'); obj=obj_read(path)
        gpath=path.with_suffix('.glb'); glb=glb_read(gpath)
        raw=topology(obj['positions'],obj['faces'])
        render=topology(obj['render_positions'],obj['render_faces'])
        unique=topology(obj['positions'],unique_faces(obj['faces']))
        gt=topology(glb['positions'],glb['faces'])
        assert render['position_count']==gt['position_count']
        assert render['triangles']==gt['triangles']
        assert render['connected_components']==gt['connected_components']
        assert len(obj['faces'])==2*len(unique_faces(obj['faces']))
        groups=collections.defaultdict(list)
        for f in obj['faces']: groups[tuple(sorted(f))].append(f)
        def parity(f):
            return sum(f[i]>f[j] for i in range(len(f)) for j in range(i+1,len(f)))%2
        opposite=all(len(fs)==2 and parity(fs[0])!=parity(fs[1]) for fs in groups.values())
        assert opposite
        materials=glb['document']['materials']
        report['public_assets'].append({"name":name,"creator":"Kenney","license":"CC0; bundled License.txt",
            "page":"https://kenney.nl/assets/nature-kit", "obj_file":str(path.relative_to(ROOT)),
            "obj_file_integrity":digest(path),"glb_file":str(gpath.relative_to(ROOT)),"glb_file_integrity":digest(gpath),
            "obj_logical_topology":raw,"obj_uv_count":len(obj['uvs']),"obj_normal_count":len(obj['normals']),
            "obj_expanded_render_vertex_topology":render,"glb_raw_render_vertex_topology":gt,
            "analysis_only_unique_unoriented_triangles":unique,
            "every_triangle_has_opposite_winding_duplicate":opposite,
            "material_count":len(materials),"alpha_modes":[m.get('alphaMode','OPAQUE') for m in materials],
            "glb_mesh_node_transforms":[n for n in glb['document']['nodes'] if 'mesh' in n],
            "root_blade_semantics":"No authored root mask or guide/blade IDs found in inspected OBJ/GLB; topology components are not validated botanical identities.",
            "inspection_limit":"Counts use local mesh positions/indices. GLB scene node has Y translation -0.05; counts are unaffected. No inferred OBJ-to-GLB vertex correspondence or axis equivalence is used."})
        report['checks'].append({"name":f'{name}: OBJ (position, UV, normal) expansion agrees with GLB vertex/triangle/component counts; all OBJ triangles have opposite-winding mates',"result":"PASS"})
    report['check_count']=len(report['checks'])
    (ROOT/'fixture_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({"checks":report['check_count'],"all_passed":True,
        "public":[{"name":m['name'],"logical_components":m['obj_logical_topology']['connected_components'],
                   "render_components":m['glb_raw_render_vertex_topology']['connected_components']} for m in report['public_assets']],
        "fixtures":[{"name":m['id'],"components":m['logical_topology']['connected_components'],
                     "vertices":m['logical_topology']['position_count'],"triangles":m['logical_topology']['triangles']} for m in report['synthetic_fixtures']]},indent=2))


if __name__ == '__main__':
    main()

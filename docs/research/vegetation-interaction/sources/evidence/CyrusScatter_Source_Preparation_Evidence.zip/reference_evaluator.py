"""Cyrus preparation study: proposed CPU guide evaluator, not a Max plug-in.

Python 3, standard library only. Run: python reference_evaluator.py
The generated JSON records arithmetic checks, not DCC, renderer or speed tests.
This evaluates already-authored bindings. It does not extract or fit guides.
"""
from math import acos, cos, sin, sqrt, pi
from pathlib import Path
import json

EPS = 1e-12

def add(a, b): return tuple(x + y for x, y in zip(a, b))
def sub(a, b): return tuple(x - y for x, y in zip(a, b))
def mul(a, t): return tuple(x * t for x in a)
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def norm(a): return sqrt(dot(a, a))
def unit(a):
    n = norm(a)
    if n < EPS: raise ValueError('Zero vector / invalid frame')
    return mul(a, 1 / n)
def mix(a, b, t): return add(mul(a, 1-t), mul(b, t))
def qmul(a, b):
    w, v, z, t = a
    x, y, r, s = b
    return (w*x-v*y-z*r-t*s, w*y+v*x+z*s-t*r,
            w*r-v*s+z*x+t*y, w*s+v*r-z*y+t*x)
def qconj(q): return (q[0], -q[1], -q[2], -q[3])
def qrotate(q, v): return qmul(qmul(q, (0, *v)), qconj(q))[1:]
def qaxis(axis, a): return (cos(a/2), *mul(unit(axis), sin(a/2)))
def qslerp(a, b, t):
    a, b = unit(a), unit(b)
    d = dot(a, b)
    if d < 0: b, d = mul(b, -1), -d
    d = max(-1, min(1, d))
    if d > .9995: return unit(mix(a, b, t))
    th = acos(d)
    return add(mul(a, sin((1-t)*th)/sin(th)), mul(b, sin(t*th)/sin(th)))

def sample(guide, s):
    """Linear center; SLERP transport; linear UNWRAPPED twist, rest-s knots.

    Transport quaternions and twist are separate. The binding coordinate s is
    never reprojected onto the deformed guide. Zero-length center spans and
    transport construction are preparation/driver validation responsibilities.
    """
    knots = guide['knots']
    if not 0 <= s <= 1: raise ValueError('Binding coordinate outside [0,1]')
    if len(knots) < 2 or knots[0] != 0 or knots[-1] != 1:
        raise ValueError('Guide needs endpoints 0 and 1')
    if any(b <= a for a, b in zip(knots, knots[1:])):
        raise ValueError('Guide knots must increase strictly')
    k = next((k for k in range(len(knots)-1) if s <= knots[k+1]), len(knots)-2)
    t = (s - knots[k]) / (knots[k+1] - knots[k])
    c = mix(guide['centers'][k], guide['centers'][k+1], t)
    q = qslerp(guide['transport'][k], guide['transport'][k+1], t)
    theta = (1-t)*guide['twist'][k] + t*guide['twist'][k+1]
    return c, unit(qmul(q, qaxis((0,0,1), theta)))

def capture(p0, influences, rest_guides, pin=0):
    """influences: (guide_id, fixed rest-s, nonnegative normalized weight)."""
    if not 0 <= pin <= 1: raise ValueError('Pin mask outside [0,1]')
    if not influences or min(w for _, _, w in influences) < 0:
        raise ValueError('Missing or negative weights')
    if abs(sum(w for _, _, w in influences)-1) > 1e-10:
        raise ValueError('Weights must sum to one')
    bind = []
    for key, s, weight in influences:
        c0, q0 = sample(rest_guides[key], s)
        d = qrotate(qconj(q0), sub(p0, c0))
        bind.append(dict(guide=key, s=s, weight=weight, offset=d))
    return dict(rest=tuple(p0), pin=pin, influences=bind)

def evaluate(binding, guides):
    q = (0., 0., 0.)
    for inf in binding['influences']:
        c, rot = sample(guides[inf['guide']], inf['s'])
        q = add(q, mul(add(c, qrotate(rot, inf['offset'])), inf['weight']))
    return mix(q, binding['rest'], binding['pin'])

def triangle_normal(p): return unit(cross(sub(p[1],p[0]), sub(p[2],p[0])))
def box(points): return ([min(p[k] for p in points) for k in range(3)],
                         [max(p[k] for p in points) for k in range(3)])

def run_checks():
    identity = (1.,0.,0.,0.)
    straight = dict(knots=[0.,1.], centers=[(0.,0.,0.),(0.,0.,1.)],
                    transport=[identity,identity], twist=[0.,0.])
    curved = dict(knots=[0.,.5,1.], centers=[(0.,0.,0.),(.2,0.,.45),(.5,.1,.8)],
                  transport=[identity,qaxis((0,1,0),.4),qaxis((0,1,0),.8)],
                  twist=[0.,.7,2.2])
    bent = dict(knots=[0.,1.], centers=[(0.,0.,0.),(.7,.2,.65)],
                transport=[identity,qaxis((0,1,0),.9)], twist=[0.,1.4])
    out = []
    def record(key, name, metric, tolerance, passed, scope):
        out.append(dict(id=key,name=name,metric=metric,tolerance=tolerance,
                        passed=passed,scope=scope))
        assert passed, name

    # Rest curvature + twist identity, including a blended binding and soft pin.
    errors=[]
    for s in [0.,.125,.4,.5,.7,1.]:
        p=(.1+s*.3,.04,s*.8)
        b=capture(p,[('a',s,.35),('b',s,.65)],{'a':curved,'b':straight},pin=.23)
        errors.append(norm(sub(evaluate(b,{'a':curved,'b':straight}),p)))
    record('E01','Rest pose identity with curvature, twist and blended weights',
           max(errors),1e-12,max(errors)<1e-12,'Arithmetic only; supplied binding')

    b=capture((.07,0.,0.),[('g',0.,1.)],{'g':straight},pin=1.)
    err=norm(sub(evaluate(b,{'g':bent}),b['rest']))
    record('E02','Hard root patch vertex remains fixed',err,0.,err==0.,
           'Pin mask only; angular stiffness is not simulated')

    widths=[]
    for s in [.125,.4,.75,1.]:
        positions=[]
        for x in [-.06,.06]:
            c,q=sample(curved,s)
            p=add(c,qrotate(q,(x,0.,0.)))
            b=capture(p,[('g',s,1.)],{'g':curved})
            positions.append(evaluate(b,{'g':bent}))
        widths.append(abs(norm(sub(*positions))-.12))
    record('E03','Single-guide cross-section width preserved',max(widths),1e-12,
           max(widths)<1e-12,'One influence, equal s, pin=0, orthonormal frames')

    twist=dict(straight,twist=[0.,4*pi])
    _,q=sample(twist,.125)
    error=norm(sub(qrotate(q,(1.,0.,0.)),(0.,1.,0.)))
    record('E04','Two full turns retain the intermediate 90-degree twist',error,
           1e-12,error<1e-12,'Unwrapped angle interpolation, not quaternion winding inference')

    # Render splits are an explicit mapping, never proximity inferred here.
    analysis=[capture((-.1,0.,0.),[('g',0.,1.)],{'g':straight}),
              capture((.1,0.,1.),[('g',1.,1.)],{'g':straight})]
    deformed=[evaluate(b,{'g':bent}) for b in analysis]
    mapping=[0,1,0,1]
    render=[deformed[i] for i in mapping]
    uv=[(0.,0.),(1.,1.),(.5,0.),(.5,1.)]
    ok=render[0]==render[2] and uv[0]!=uv[2]
    record('E05','Render-position duplicates move together while UVs stay split',
           {'render_vertices':4,'analysis_vertices':2},None,ok,
           'Explicit correspondence, not an automatic weld')

    p=[(0.,0.,0.),(1.,0.,1.),(0.,1.,1.)]
    n=triangle_normal(p)
    scale=(2.,.5,3.)
    pp=[tuple(x*y for x,y in zip(v,scale)) for v in p]
    actual=triangle_normal(pp)
    expected=unit(tuple(x/y for x,y in zip(n,scale)))
    err=norm(sub(actual,expected))
    record('E06','Nonuniform placement normals use inverse transpose',err,1e-12,
           err<1e-12,'Geometric triangle normal; shader and explicit normal export untested')

    mirrored=[(-v[0],v[1],v[2]) for v in p]
    corrected=triangle_normal([mirrored[i] for i in [0,2,1]])
    err=norm(sub(corrected,(-n[0],n[1],n[2])))
    record('E07','Baked mirror needs reversed triangle corner order',err,1e-12,
           err<1e-12,'All map/normal corner indices must follow the same permutation')

    positions=[evaluate(capture((x,0.,s),[('g',s,1.)],{'g':straight}),{'g':bent})
               for s in [0.,.2,.5,.8,1.] for x in [-.1,.1]]
    low,high=box(positions)
    ok=all(low[k]<=p[k]<=high[k] for p in positions for k in range(3))
    record('E08','Published bounds contain all evaluated mesh positions',
           {'min':low,'max':high},None,ok,'Static mesh only; no renderer displacement expansion')

    plus=dict(straight,transport=[qaxis((0,0,1),pi/2)]*2)
    minus=dict(straight,transport=[qaxis((0,0,1),-pi/2)]*2)
    b=capture((1.,0.,1.),[('a',1.,.5),('b',1.,.5)],{'a':straight,'b':straight})
    length=norm(sub(evaluate(b,{'a':plus,'b':minus}),(0.,0.,1.)))
    record('E09','Expected limitation: opposing blended frames collapse width',
           {'remaining_radius':length,'rest_radius':1.},1e-12,length<1e-12,
           'Counterexample; no general volume/width preservation for multiple guides')

    a0=sample(straight,0.)[0]
    lean_rotation=qaxis((0,1,0),pi/4)
    leaned=dict(straight,centers=[(0.,0.,0.),qrotate(lean_rotation,(0.,0.,1.))],
                transport=[lean_rotation]*2)
    a1=sample(leaned,0.)[0]
    t0=qrotate(sample(straight,0.)[1],(0.,0.,1.))
    t1=qrotate(sample(leaned,0.)[1],(0.,0.,1.))
    ok=a0==a1 and norm(sub(t0,t1))>.1
    record('E10','Fixed guide root position does not determine its orientation',
           {'anchor_displacement':norm(sub(a0,a1)),'tangent_difference':norm(sub(t0,t1))},
           None,ok,'Constraint distinction; not a physical root solver')
    return {'status':'passed','check_count':len(out),'checks':out,
            'excluded':['Max runtime','renderer output','collision fitting','automatic extraction',
                        'preparation time','performance benchmark'],
            'implementation':'Proposed reference evaluator, Python standard library'}

if __name__=='__main__':
    result=run_checks()
    target=Path(__file__).with_name('evaluator_checks.json')
    target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'checks':result['check_count'],
                      'output':str(target)},indent=2))

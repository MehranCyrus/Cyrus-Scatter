# Owner C coverage and execution status

All rows refer to the frozen v1 contract. “Executed” means the headless C++ test ran in the recorded Linux/GCC environment. It does not imply Max, renderer or production qualification.

| Requirement | Status | Executed evidence / limitation |
| --- | --- | --- |
| Export `cyrus_vegetation_delivery`, link `cyrus_prototype_contract`, `delivery_` CTests | Implemented, executed | Configure/build and four CTest groups passed in normal and ASan/UBSan builds |
| Linear center + normalized shortest-path quaternion slerp for rest and deformed sampling | Implemented, executed | clear rest, authored pose, u endpoints, quaternion-sign and longitudinal-offset tests |
| Explicit full xyz offset, span/u binding and no positional weld inference | Implemented, executed | longitudinal offset and seam/logical-ID order tests |
| Unsupported full turn / ambiguous pi frame rejection | Implemented, executed | `evaluator.unsupported_full_turn`, `evaluator.ambiguous_pi` |
| Rest reconstruction before output | Implemented, executed | clear controls and corrupted rest-position rejection |
| UV, topology, face material, revision and exact bounds preservation | Implemented, executed | independent corruption tests for each field |
| Finite geometric normals | Implemented, executed | normals recomputed and corruption rejected; custom normals/tangents unsupported |
| Envelope declarations checked against complete offsets | Implemented, executed | deliberately too-small radius/bound rejected |
| Privately staged complete mesh; no partial success | Implemented, executed | failure/cancel/resource tests require empty evaluator mesh |
| Independent pose re-evaluation | Implemented, executed | validator has a separate reference sampler and rejects translated-but-plausible mesh output |
| Fixed root, root modes and span lengths | Implemented, executed | PositionOnly, ClampFrame, SoftFrame, root movement, root-contained and length failures |
| Exact sphere whole-triangle clearance | Implemented, executed | face-interior crossing, containment and visible-width cases |
| Sound OBB whole-triangle test | Implemented, executed | complete triangle/AABB SAT in OBB-local coordinates; rotated, face-interior, containment and clear controls |
| OBB clearance metric disclosure | Implemented | axis-expanded L-infinity certificate; SAT overlap metric explicitly labeled non-exact |
| Multiple obstacles | Implemented, executed | clear box plus intersecting sphere; all obstacles are visited |
| Cancellation | Implemented; partial execution | pre-set cancellation executed; asynchronous mid-loop timing/injection not executed |
| Resource limits | Implemented, executed | render counts, memory estimate and visible obstacle/triangle pair budget |
| Allocation failure | Implemented, not fault-injected | public boundaries catch `std::bad_alloc`; no deterministic allocator-failure harness supplied |
| Deterministic static repeatability | Implemented by pure static code; not separately bit-compared across platforms | same-process fixtures deterministic; cross-platform bit identity not claimed |
| Diagnostic OBJ | Implemented, executed | temporary OBJ written/read for nonzero size; explicitly not renderer/Bake evidence |
| Semantic IDs in standalone `EvaluatedMesh` | Partial due frozen interface | order association retained through `PreparedRibbon`; shared change request adds ID arrays |
| Arbitrary vegetation, full R11 preparation, multi-guide binding | Unsupported by design | narrow v1 sampler only |
| Exact Euclidean OBB penetration depth | Unsupported | validator reports a conservative SAT-axis proxy only |
| Measured peak memory / performance benchmark | Not executed | memory admission is a conservative payload/scratch estimate; CTest times are not performance claims |
| Windows/MSVC, Max 2027, viewport, renderer, Bake, Undo/save-load | Not executed | reserved for local coordinator gates |

# Execution evidence

These files are actual outputs from the final normalized-mtime source copy used for compilation. Source bytes and frozen hashes match the handoff; only copied file timestamps were normalized because the ZIP timestamps were several hours ahead of the execution container clock.

- `configure.log`, `build.log`, `ctest.log`: warning-as-error Debug build and CTest.
- `all-tests.log`: 23 individually named executed checks.
- `configure-sanitizers.log`, `build-sanitizers.log`, `ctest-sanitizers.log`: AddressSanitizer + UndefinedBehaviorSanitizer build and CTest.
- `commands.txt`: exact command sequence and exit status statement.
- `environment.txt`: compiler, CMake, OS and contract identity.
- `test-summary.json`: machine-readable test summary and metric conventions.
- `COVERAGE.md`: implemented/partial/unsupported/not-executed requirement mapping.

No test log in this directory is a Max, renderer, Bake, visual-quality, performance or production-asset result.

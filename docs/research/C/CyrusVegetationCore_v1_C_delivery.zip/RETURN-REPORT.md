# CyrusVegetationCore v1 — owner C return report

## Identity and scope

- Role: **C — ribbon delivery and independent visible-surface validation**
- Edition: `CyrusScatter_Vegetation_Core_Handoff_v1`
- Owned directory: `docs/research/vegetation-core-handoff/starter/delivery/`
- Frozen header SHA-256: `f5c9b72e513a1c6ceea74f79bc0005175381691b65c99af47dc2debaebc7e42f`
- Frozen shared-contract SHA-256: `61463bdf7e354b31191b6d9030686eb1ab0d8c1b83d6a7e4167713e92bdf2d80`
- Exported target: `cyrus_vegetation_delivery`
- Implemented frozen entry points: `evaluate_ribbon`, `validate_candidate`

No frozen file or non-delivery module byte was changed. Scope verification and all frozen hashes are recorded in `delivery/evidence/scope-integrity.txt`.

## Implementation result

`evaluate_ribbon` implements explicit one-guide span/u sampling with complete xyz offsets, linear centers and normalized shortest-path quaternion slerp for both rest reconstruction and deformed evaluation. It preserves binding order, UV seams, topology, face materials and source revision, creates finite area-weighted geometric normals and exact position bounds, and publishes only a complete private stage. Unsupported full turns and ambiguous near-pi frame transitions are rejected.

`validate_candidate` does not call A, B, Jolt or the evaluator. It independently re-samples the pose, checks root modes, length/frame/source/envelope/mesh correspondence, then checks every visible triangle against every obstacle. Sphere tests use exact point-to-triangle minimum distance. OBB tests use full triangle/AABB SAT after local transformation and conservative local-axis clearance expansion. OBB overlap values are explicitly labeled proxies rather than exact physical penetration.

## Actual execution

Final normal build:

- Linux x86_64, GCC 14.2.0, CMake 3.31.6, C++20
- Debug build with compiler warnings promoted to errors
- 4/4 CTest groups passed
- 23/23 individually named headless checks passed

Final sanitizer build:

- AddressSanitizer and UndefinedBehaviorSanitizer enabled
- 4/4 CTest groups passed

Exact commands, exit codes and logs are under `delivery/evidence/`. No product performance measurement was performed; CTest elapsed times are not presented as benchmarks.

## Coverage summary

Executed positive controls include clear rest, the catalog-authored feasible sphere pose, a clear rotated-box case and valid two-obstacle traversal. Executed rejection/diagnostic cases include planted-root violation and containment, bad length/frame/revision, invalid prepared envelope, visible width beyond a clear center guide, sphere/box face-interior intersections with all triangle vertices outside, containment, rotated OBB, mesh topology/UV/material/bounds/normal/pose corruption, quaternion sign, unsupported full turn, cancellation and resource limits.

The catalog-style too-small span radius is rejected as invalid preparation. A separate valid-envelope version demonstrates the visible ribbon/sphere overlap independently; this is not represented as failure of an admitted conservative envelope.

## Known limitations

- Narrow v1 only: one guide/ribbon, static sphere and rigid OBB obstacles, local metre patch.
- No arbitrary source extraction, multi-guide skinning, full-turn twist, mesh/SDF obstacles, alpha silhouettes, dynamics or self-contact.
- Custom authored normals/tangents are deferred; undefined geometric normals are rejected.
- OBB clearance is conservative and may produce false rejections near rounded Euclidean-clear corners.
- Memory admission is a conservative vector-payload/scratch estimate, not a measured allocator peak.
- Deterministic allocator-failure injection and asynchronous mid-loop cancellation timing were not executed.
- Windows/MSVC, Max 2027, viewport, production renderer, Bake, Undo and save/reopen were not executed.
- The frozen `EvaluatedMesh` does not carry semantic ID vectors; order association works only while `PreparedRibbon` remains available. `CONTRACT_CHANGE_REQUEST.md` requests the smallest coordinated change.

## Contract change request

Add `render_vertex_ids` and `logical_vertex_ids` to `EvaluatedMesh` in a future coordinated edition. This makes seam/identity preservation explicit for downstream host or Bake transport without treating coincident coordinates as weld authority. The v1 header was not modified.

## Local integration note

Place the returned `delivery/` directory under the unchanged frozen starter. Configure the starter normally; it will add the module and expose `cyrus_vegetation_delivery`. After owner B returns a candidate, the coordinator should verify matching generation/source identity, call `evaluate_ribbon`, then call `validate_candidate` against the same immutable snapshot before any host publication. A validator `Pass` is only a narrow core certificate; current host dependencies plus viewport/render/Bake agreement remain local gates.
